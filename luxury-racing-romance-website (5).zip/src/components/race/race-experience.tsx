"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, animate, motion, useSpring, useTransform } from "framer-motion";
import { useSettings } from "@/lib/store";
import { playChime, playEngineRev } from "@/lib/audio";
import { FloatingParticles } from "@/components/floating-particles";
import { clamp, cn } from "@/lib/utils";

type Phase = "lights" | "rev" | "pole" | "track";

/** Closed circuit, drawn as one SVG path so the car can follow it. */
const TRACK_D =
  "M 160 300 C 160 130, 380 70, 520 150 S 720 300, 860 190 S 980 360, 820 440 S 470 480, 370 400 S 160 470, 160 300 Z";

/** Checkpoint positions along the track (0 = start line, 1 = back to the line). */
const CHECKPOINTS = [0.12, 0.28, 0.44, 0.6, 0.76, 0.9];

/* ───────────── The car (MRS CHOPRA livery) ───────────── */
function RaceCarGroup() {
  return (
    <g>
      <rect x="-30" y="-19" width="16" height="8" rx="2" fill="#0f0f10" />
      <rect x="16" y="-19" width="16" height="8" rx="2" fill="#0f0f10" />
      <rect x="-30" y="11" width="16" height="8" rx="2" fill="#0f0f10" />
      <rect x="16" y="11" width="16" height="8" rx="2" fill="#0f0f10" />
      <path
        d="M -42 -2 Q -40 -9 -30 -9 L -10 -11 Q 0 -18 14 -12 L 34 -8 Q 44 -6 44 2 L 44 6 Q 44 9 40 9 L -36 9 Q -42 9 -42 4 Z"
        fill="#e10600"
        stroke="#6a0000"
        strokeWidth="0.8"
      />
      <path d="M -36 -1 L 38 -1" stroke="#ffffff" strokeWidth="1.6" />
      <ellipse cx="2" cy="-8" rx="7" ry="3.6" fill="#0a0a0a" />
      <circle cx="4" cy="-10" r="2.6" fill="#ffffff" />
      <text x="-2" y="6" fontSize="4.2" fill="#ffffff" textAnchor="middle" fontFamily="Orbitron, sans-serif" fontWeight="900" letterSpacing="0.3">
        MRS CHOPRA
      </text>
      <text x="36" y="-3.2" fontSize="3.6" fill="#f6e7b0" fontFamily="Orbitron, sans-serif" fontWeight="700">
        ❤
      </text>
    </g>
  );
}

/* ───────────── Rev counter / speedometer ───────────── */
function Gauge({ value, max, label }: { value: number; max: number; label: string }) {
  const target = -120 + (clamp(value, 0, max) / max) * 240;
  const angle = useSpring(target, { stiffness: 90, damping: 14 });
  useEffect(() => {
    angle.set(target);
  }, [angle, target]);
  const x2 = useTransform(angle, (a) => (Math.sin((a * Math.PI) / 180) * 74));
  const y2 = useTransform(angle, (a) => -Math.cos((a * Math.PI) / 180) * 74);

  return (
    <div className="relative h-36 w-36 shrink-0 sm:h-44 sm:w-44">
      <svg viewBox="-100 -100 200 200" className="h-full w-full" aria-hidden>
        <circle r="94" fill="rgba(0,0,0,0.75)" stroke="rgba(255,255,255,0.14)" strokeWidth="2" />
        {Array.from({ length: 11 }, (_, i) => {
          const a = ((-120 + i * 24) * Math.PI) / 180;
          const r1 = 84;
          const r2 = i % 2 ? 76 : 70;
          return (
            <line
              key={i}
              x1={Math.sin(a) * r1}
              y1={-Math.cos(a) * r1}
              x2={Math.sin(a) * r2}
              y2={-Math.cos(a) * r2}
              stroke={i >= 8 ? "#ff3b30" : "#ffffff"}
              strokeWidth="3"
              strokeLinecap="round"
            />
          );
        })}
        <motion.line x1={0} y1={0} x2={x2} y2={y2} stroke="#e10600" strokeWidth="4" strokeLinecap="round" />
        <circle r="7" fill="#e10600" />
      </svg>
      <div className="absolute inset-x-0 bottom-[20%] text-center">
        <div className="font-f1 text-2xl font-black tabular-nums">{Math.round(value)}</div>
        <div className="text-[9px] tracking-[0.3em] text-white/55">{label}</div>
      </div>
    </div>
  );
}

export function RaceExperience() {
  const { settings, markDone } = useSettings();
  const race = settings.race;

  const [phase, setPhase] = useState<Phase>("lights");
  const [lit, setLit] = useState(0);
  const [rpm, setRpm] = useState(0);

  const [pos, setPos] = useState(0);
  const posRef = useRef(0);
  const [speed, setSpeed] = useState(0);
  const [driving, setDriving] = useState(false);
  const [reached, setReached] = useState(0);
  const [activeIdx, setActiveIdx] = useState<number | null>(null);
  const [finished, setFinished] = useState(false);

  const [len, setLen] = useState(0);
  const pathRef = useRef<SVGPathElement>(null);
  const controls = useRef<ReturnType<typeof animate>[]>([]);

  useEffect(() => {
    const list = controls.current;
    return () => list.forEach((c) => c.stop());
  }, []);

  // Starting lights illuminate one by one.
  useEffect(() => {
    if (phase !== "lights" || lit >= 5) return;
    const t = window.setTimeout(() => setLit((l) => l + 1), lit === 0 ? 500 : 480);
    return () => window.clearTimeout(t);
  }, [phase, lit]);

  // After the pole-position moment, the circuit opens automatically.
  useEffect(() => {
    if (phase !== "pole") return;
    const t = window.setTimeout(() => setPhase("track"), 4600);
    return () => window.clearTimeout(t);
  }, [phase]);

  // Measure the track once it is on screen.
  useEffect(() => {
    if (phase === "track" && pathRef.current) setLen(pathRef.current.getTotalLength());
  }, [phase]);

  const startEngine = () => {
    playEngineRev();
    setPhase("rev");
    controls.current.push(
      animate(0, 9.4, {
        duration: 2.4,
        ease: "easeInOut",
        onUpdate: (v) => setRpm(v),
        onComplete: () => setPhase("pole"),
      }),
    );
  };

  const pointAt = useCallback(
    (f: number) => {
      const p = pathRef.current;
      if (!p || !len) return { x: 160, y: 300, a: 0 };
      const s = clamp(f, 0, 1) * len;
      const pt = p.getPointAtLength(s);
      const ahead = p.getPointAtLength(Math.min(len, s + 1.5));
      const behind = p.getPointAtLength(Math.max(0, s - 1.5));
      const a = (Math.atan2(ahead.y - behind.y, ahead.x - behind.x) * 180) / Math.PI;
      return { x: pt.x, y: pt.y, a };
    },
    [len],
  );

  const driveTo = (target: number, onArrive: () => void) => {
    if (driving) return;
    setDriving(true);
    const from = posRef.current;
    const dist = Math.max(0.02, target - from);
    controls.current.push(
      animate(from, target, {
        duration: 0.9 + dist * 5,
        ease: [0.45, 0, 0.55, 1],
        onUpdate: (v) => {
          posRef.current = v;
          setPos(v);
          setSpeed(Math.round(150 + 120 * Math.abs(Math.sin(v * Math.PI * 14))));
        },
        onComplete: () => {
          setSpeed(0);
          setDriving(false);
          onArrive();
        },
      }),
    );
  };

  const nextStep = () => {
    if (driving || finished) return;
    if (reached < CHECKPOINTS.length) {
      const i = reached;
      driveTo(CHECKPOINTS[i], () => {
        setReached(i + 1);
        setActiveIdx(i);
        playChime();
      });
    } else {
      driveTo(1, () => {
        setFinished(true);
        setActiveIdx(null);
        markDone("race:finished");
        playChime();
      });
    }
  };

  const replay = () => {
    posRef.current = 0;
    setPos(0);
    setReached(0);
    setActiveIdx(null);
    setFinished(false);
    setSpeed(0);
  };

  const car = pointAt(pos);
  const cps = CHECKPOINTS.map((f) => pointAt(f));
  const activeCp = activeIdx !== null ? race.checkpoints[activeIdx] : null;
  const nextIsFinish = reached >= CHECKPOINTS.length;

  /* ───────────── Phase: lights + start ───────────── */
  if (phase === "lights") {
    return (
      <section className="carbon relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-6 pb-16 pt-28 text-center">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#e10600] to-transparent" />
        <p className="label !text-[#ff4b3e]">Formula Love · Grid Walk</p>

        <div className="mt-10 flex gap-3 rounded-full bg-black/60 px-6 py-4 sm:gap-6 sm:px-10">
          {[0, 1, 2, 3, 4].map((i) => (
            <motion.span
              key={i}
              aria-hidden
              className="block h-9 w-9 rounded-full border-2 border-black sm:h-14 sm:w-14"
              animate={{
                backgroundColor: i < lit ? "#ff1e1e" : "#2a0a0a",
                boxShadow: i < lit ? "0 0 40px 10px rgba(255,30,30,0.6)" : "0 0 0 0 rgba(0,0,0,0)",
              }}
              transition={{ duration: 0.25 }}
            />
          ))}
        </div>
        <p className="mt-4 text-[11px] font-bold tracking-[0.3em] text-white/50">
          {lit < 5 ? `LIGHTS ${lit}/5` : "LIGHTS OUT · READY"}
        </p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="font-f1 mt-10 max-w-4xl text-2xl font-black leading-tight tracking-tight sm:text-5xl lg:text-6xl"
        >
          {race.welcomeTitle}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="font-display mt-5 max-w-xl text-lg italic text-white/75 sm:text-2xl"
        >
          {race.subtitle}
        </motion.p>

        <div className="mt-12 h-16">
          <AnimatePresence>
            {lit >= 5 && (
              <motion.button
                key="start"
                type="button"
                onClick={startEngine}
                initial={{ opacity: 0, scale: 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 14 }}
                className="btn btn-accent !px-9 !py-4 !text-sm"
              >
                START THE ENGINE ❤️
              </motion.button>
            )}
          </AnimatePresence>
        </div>
        <button type="button" onClick={() => setPhase("track")} className="mt-4 text-xs text-white/40 underline-offset-4 hover:text-white hover:underline">
          Skip intro → straight to the circuit
        </button>
      </section>
    );
  }

  /* ───────────── Phase: engine rev ───────────── */
  if (phase === "rev") {
    return (
      <section className="carbon relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-6 text-center">
        <motion.div
          className="flex flex-col items-center gap-8"
          animate={{ x: [0, -3, 3, -2, 2, 0], y: [0, 1, -1, 1, 0] }}
          transition={{ duration: 0.22, repeat: Infinity }}
        >
          <Gauge value={rpm} max={10} label="RPM ×1000" />
          <p className="font-f1 blink text-lg font-black tracking-[0.3em] text-[#ff4b3e] glow-red">ENGINE ON</p>
        </motion.div>
      </section>
    );
  }

  /* ───────────── Phase: pole position ───────────── */
  if (phase === "pole") {
    return (
      <section className="carbon relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-6 text-center">
        <motion.div
          aria-hidden
          className="absolute inset-0 bg-[linear-gradient(90deg,transparent,#e10600,transparent)]"
          initial={{ x: "-100%" }}
          animate={{ x: "100%" }}
          transition={{ duration: 1.1, ease: "easeInOut" }}
        />
        <FloatingParticles count={14} variant="sparks" colors={["#ff4b3e", "#ffffff"]} />
        <motion.div
          initial={{ x: -320, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.1, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="w-full max-w-2xl"
        >
          <svg viewBox="-60 -30 120 60" className="mx-auto h-auto w-full max-w-md drop-shadow-[0_0_30px_rgba(225,6,0,0.7)]" aria-hidden>
            <RaceCarGroup />
          </svg>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.3 }}
          className="font-f1 relative mt-6 text-2xl font-black leading-tight glow-red sm:text-5xl lg:text-6xl"
        >
          {race.polePosition}
        </motion.h2>
        <motion.button
          type="button"
          onClick={() => setPhase("track")}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.4 }}
          className="btn btn-ghost mt-10"
        >
          Enter the circuit →
        </motion.button>
      </section>
    );
  }

  /* ───────────── Phase: race track ───────────── */
  return (
    <section className="carbon relative min-h-[100svh] overflow-hidden px-4 pb-20 pt-24 sm:px-8">
      <div className="mx-auto flex max-w-6xl flex-col gap-6">
        <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="label !text-[#ff4b3e]">MRS CHOPRA Grand Prix · Lap 1 of 1</p>
            <h1 className="font-f1 mt-2 text-xl font-black leading-tight sm:text-3xl">{race.polePosition}</h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-white/60">
            <span className="tabular rounded-full border border-white/15 px-3 py-1.5">
              Checkpoints {reached}/{CHECKPOINTS.length}
            </span>
            <button type="button" onClick={replay} className="btn btn-ghost !min-h-9 !px-4 !py-2 !text-[10px]">
              Restart
            </button>
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-[auto_1fr]">
          {/* Dashboard */}
          <div className="glass-strong flex flex-row items-center gap-5 rounded-[28px] p-5 lg:flex-col lg:justify-center">
            <Gauge value={speed} max={320} label="KM/H" />
            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={nextStep}
                disabled={driving || finished}
                className="btn btn-accent !text-[11px]"
              >
                {finished
                  ? "Finished 🏁"
                  : driving
                    ? "Driving…"
                    : nextIsFinish
                      ? "Cross the finish line 🏁"
                      : `Drive to checkpoint ${String(reached + 1).padStart(2, "0")} →`}
              </button>
              <p className="max-w-[16rem] text-xs leading-relaxed text-white/55">
                The car only goes forward, like a real race. Each checkpoint unlocks a memory.
              </p>
            </div>
          </div>

          {/* Track */}
          <div className="glass-strong relative overflow-hidden rounded-[28px] p-2 sm:p-4">
            <svg viewBox="0 0 1000 560" className="h-auto w-full" role="img" aria-label="Race circuit with checkpoints">
              <defs>
                <filter id="race-glow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="5" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              {/* kerbs */}
              <path d={TRACK_D} fill="none" stroke="#ffffff" strokeWidth="66" strokeDasharray="16 16" opacity="0.85" />
              {/* asphalt (also the geometry the car follows) */}
              <path ref={pathRef} d={TRACK_D} fill="none" stroke="#24242a" strokeWidth="54" />
              {/* racing line */}
              <path d={TRACK_D} fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="2" strokeDasharray="4 14" />
              {/* driven trail */}
              {len > 0 && (
                <path
                  d={TRACK_D}
                  fill="none"
                  stroke="#e10600"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray={`${pos * len} ${len}`}
                  filter="url(#race-glow)"
                />
              )}
              {/* start / finish line */}
              <line x1="128" y1="300" x2="192" y2="300" stroke="#ffffff" strokeWidth="12" strokeDasharray="6 6" />
              <text x="160" y="262" fontSize="26" textAnchor="middle">🏁</text>

              {/* checkpoints */}
              {cps.map((p, i) => {
                const done = reached > i;
                const isNext = i === reached && !finished;
                return (
                  <g
                    key={i}
                    transform={`translate(${p.x} ${p.y})`}
                    onClick={() => done && setActiveIdx(i)}
                    className={done ? "cursor-pointer" : undefined}
                    role={done ? "button" : undefined}
                    aria-label={done ? `Show checkpoint ${i + 1} message` : undefined}
                  >
                    {isNext && (
                      <motion.circle
                        r={17}
                        fill="none"
                        stroke="#ffffff"
                        strokeWidth="2"
                        animate={{ r: [17, 30, 17], opacity: [0.9, 0, 0.9] }}
                        transition={{ duration: 1.6, repeat: Infinity }}
                      />
                    )}
                    <circle
                      r="17"
                      fill={done ? "var(--accent)" : "#0b0b0d"}
                      stroke={done ? "#ffffff" : "rgba(255,255,255,0.55)"}
                      strokeWidth="2"
                    />
                    <text y="5" textAnchor="middle" fontSize="13" fontWeight="700" fill="#ffffff" fontFamily="Montserrat, sans-serif">
                      {done ? "♥" : i + 1}
                    </text>
                  </g>
                );
              })}

              {/* car */}
              <g transform={`translate(${car.x} ${car.y}) rotate(${car.a}) scale(1.35)`}>
                <RaceCarGroup />
              </g>
            </svg>
          </div>
        </div>

        {/* Message / finish panel */}
        <div className="min-h-[12rem]">
          <AnimatePresence mode="wait">
            {finished ? (
              <motion.div
                key="finish"
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
                className="glass-strong relative overflow-hidden rounded-[28px] p-8 text-center sm:p-14"
              >
                <FloatingParticles count={26} variant="sparks" colors={["#e10600", "#ffffff", "#f6e7b0"]} />
                <p className="label !text-[#ff4b3e]">Chequered flag</p>
                <h2 className="font-f1 relative mt-4 text-2xl font-black leading-tight glow-red sm:text-4xl lg:text-5xl">
                  {race.finishLine}
                </h2>
                <p className="font-display relative mx-auto mt-5 max-w-xl text-base italic text-white/75 sm:text-lg">
                  Har race khatam hoti hai, par tumse judi har kahani naye lap jaisi lagti hai.
                </p>
                <div className="relative mt-8 flex flex-wrap justify-center gap-3">
                  <button type="button" onClick={replay} className="btn btn-ghost">
                    Replay the race
                  </button>
                  <Link href="/mrs-chopra" className="btn btn-accent">
                    Madam Ji&apos;s world 👑
                  </Link>
                </div>
              </motion.div>
            ) : activeCp ? (
              <motion.div
                key={`cp-${activeIdx}`}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.5 }}
                className="glass rounded-[28px] p-7 sm:p-10"
              >
                <p className="label !text-[#ff4b3e]">
                  Checkpoint {String((activeIdx ?? 0) + 1).padStart(2, "0")} · {activeCp.title}
                </p>
                <p className="font-display mt-4 text-xl leading-relaxed text-white sm:text-3xl">{activeCp.message}</p>
              </motion.div>
            ) : (
              <motion.div
                key="hint"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="glass flex min-h-[12rem] flex-col items-center justify-center rounded-[28px] p-8 text-center"
              >
                <p className="label">Pit wall</p>
                <p className="font-display mt-4 max-w-lg text-lg italic text-white/70">
                  Press the big red button to drive to the first checkpoint. Har checkpoint pe ek naya message khulega.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Checkpoint index */}
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {race.checkpoints.map((cp, i) => {
            const done = reached > i;
            const isNext = i === reached;
            return (
              <li key={i}>
                <button
                  type="button"
                  disabled={!done}
                  onClick={() => setActiveIdx(i)}
                  className={cn(
                    "w-full rounded-2xl border px-3 py-3 text-left text-xs transition-all",
                    done
                      ? "border-[color:var(--accent)]/60 bg-[color:var(--accent-soft)] text-white hover:bg-[color:var(--accent-soft)]"
                      : isNext
                        ? "border-white/40 text-white/80"
                        : "border-white/10 text-white/35",
                  )}
                >
                  <span className="block text-[10px] tracking-[0.2em] text-white/50">CP {String(i + 1).padStart(2, "0")}</span>
                  <span className="mt-1 block font-semibold">{done ? cp.title : isNext ? "Next up" : "Locked"}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
