"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, type PanInfo } from "framer-motion";

type Photo = { id: string; url: string; caption: string };

type Props = {
  photos: Photo[];
  index: number;
  onClose: () => void;
  onIndex: (i: number) => void;
  counts: Record<string, number>;
  liked: string[];
  onHeart: (id: string) => void;
  onCaption: (id: string, caption: string) => void;
  onDelete: (id: string) => void;
};

/** Full-screen photo viewer with keyboard + swipe navigation and inline caption editing. */
export function Lightbox({ photos, index, onClose, onIndex, counts, liked, onHeart, onCaption, onDelete }: Props) {
  const photo = photos[index];
  const [direction, setDirection] = useState(1);
  const [draft, setDraft] = useState(photo?.caption ?? "");

  const go = (delta: number) => {
    setDirection(delta);
    onIndex((index + delta + photos.length) % photos.length);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") {
        setDirection(1);
        onIndex((index + 1) % photos.length);
      }
      if (e.key === "ArrowLeft") {
        setDirection(-1);
        onIndex((index - 1 + photos.length) % photos.length);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, photos.length, onClose, onIndex]);

  if (!photo) return null;
  const isLiked = liked.includes(photo.id);

  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -80) go(1);
    else if (info.offset.x > 80) go(-1);
  };

  return (
    <motion.div
      className="fixed inset-0 z-[110] flex flex-col bg-black/95 backdrop-blur-xl"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35 }}
      role="dialog"
      aria-modal="true"
      aria-label="Photo viewer"
    >
      <div className="flex items-center justify-between px-4 py-4 sm:px-8">
        <span className="label tabular">
          {index + 1} / {photos.length}
        </span>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              if (window.confirm("Delete this photo from this browser? This can't be undone.")) onDelete(photo.id);
            }}
            className="btn btn-ghost !min-h-10 !px-4 !py-2 !text-[10px] hover:!bg-red-500/20"
          >
            Delete
          </button>
          <button type="button" onClick={onClose} className="btn btn-ghost !min-h-10 !px-4 !py-2 !text-[10px]" aria-label="Close viewer">
            Close ✕
          </button>
        </div>
      </div>

      <div className="relative flex min-h-0 flex-1 items-center justify-center px-2 sm:px-16">
        <button
          type="button"
          onClick={() => go(-1)}
          className="btn btn-ghost absolute left-2 top-1/2 z-10 !h-11 !w-11 !min-h-0 !p-0 sm:left-6"
          aria-label="Previous photo"
        >
          ←
        </button>
        <AnimatePresence initial={false} custom={direction} mode="popLayout">
          <motion.img
            key={photo.id}
            src={photo.url}
            alt={photo.caption}
            custom={direction}
            className="max-h-[68vh] max-w-full select-none rounded-2xl object-contain shadow-[0_30px_100px_-20px_rgba(0,0,0,0.9)]"
            initial={{ opacity: 0, x: direction * 120, scale: 0.97 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: direction * -120, scale: 0.97 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.2}
            onDragEnd={onDragEnd}
            draggable={false}
          />
        </AnimatePresence>
        <button
          type="button"
          onClick={() => go(1)}
          className="btn btn-ghost absolute right-2 top-1/2 z-10 !h-11 !w-11 !min-h-0 !p-0 sm:right-6"
          aria-label="Next photo"
        >
          →
        </button>
      </div>

      <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-5 pb-8 pt-5 sm:px-8">
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => onHeart(photo.id)}
            className={`btn !min-h-10 !px-5 !py-2 !text-[11px] ${isLiked ? "btn-accent" : "btn-ghost"}`}
            aria-label={isLiked ? "You hearted this photo" : "Heart this photo"}
          >
            {isLiked ? "❤️" : "🤍"} <span className="tabular">{counts[photo.id] ?? 0}</span>
          </button>
          <p className="text-xs text-white/45">Swipe, or use the arrow keys.</p>
        </div>
        <label className="label" htmlFor="lightbox-caption">
          Caption (editable)
        </label>
        <input
          id="lightbox-caption"
          key={photo.id}
          className="field font-display text-base italic"
          value={draft}
          maxLength={160}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={() => {
            if (draft !== photo.caption) onCaption(photo.id, draft);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") (e.target as HTMLInputElement).blur();
          }}
        />
      </div>
    </motion.div>
  );
}
