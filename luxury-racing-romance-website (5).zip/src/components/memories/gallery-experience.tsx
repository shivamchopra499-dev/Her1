"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import { deletePhoto, listPhotos, updatePhoto, type PhotoRecord } from "@/lib/idb";
import { ensureSeeded, uploadFiles } from "@/lib/photos";
import { uid } from "@/lib/utils";
import { Lightbox } from "@/components/memories/lightbox";
import { MemoryTimeline } from "@/components/memories/memory-timeline";
import { MusicPlayer } from "@/components/memories/music-player";
import { FloatingParticles } from "@/components/floating-particles";

type ViewPhoto = PhotoRecord & { url: string };

const LIKED_KEY = "mrs-chopra-universe:liked";

/* ───────────── Slideshow ───────────── */
function Slideshow({
  photos,
  seconds,
  onClose,
}: {
  photos: ViewPhoto[];
  seconds: number;
  onClose: () => void;
}) {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);

  useEffect(() => {
    if (!playing || photos.length < 2) return;
    const t = window.setInterval(() => setIndex((v) => (v + 1) % photos.length), seconds * 1000);
    return () => window.clearInterval(t);
  }, [playing, photos.length, seconds]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIndex((v) => (v + 1) % photos.length);
      if (e.key === "ArrowLeft") setIndex((v) => (v - 1 + photos.length) % photos.length);
      if (e.key === " ") {
        e.preventDefault();
        setPlaying((p) => !p);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, photos.length]);

  const photo = photos[index % photos.length];

  return (
    <motion.div
      className="fixed inset-0 z-[120] bg-black"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      role="dialog"
      aria-modal="true"
      aria-label="Romantic slideshow"
    >
      <AnimatePresence mode="sync">
        <motion.img
          key={photo.id}
          src={photo.url}
          alt={photo.caption}
          className="absolute inset-0 h-full w-full object-contain"
          initial={{ opacity: 0, scale: 1.04 }}
          animate={{ opacity: 1, scale: 1.1 }}
          exit={{ opacity: 0 }}
          transition={{ opacity: { duration: 1.2 }, scale: { duration: seconds + 1.5, ease: "linear" } }}
        />
      </AnimatePresence>
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-8 pt-24 sm:p-14">
        <motion.p
          key={`cap-${photo.id}`}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display max-w-3xl text-2xl italic sm:text-4xl"
        >
          {photo.caption}
        </motion.p>
        <p className="label mt-3 !text-white/50">
          {(index % photos.length) + 1} / {photos.length}
        </p>
      </div>
      <div className="absolute right-4 top-4 flex gap-2 sm:right-6 sm:top-6">
        <button type="button" onClick={() => setPlaying((p) => !p)} className="btn btn-ghost !min-h-10 !px-4 !py-2 !text-[10px]">
          {playing ? "Pause ❚❚" : "Play ▶"}
        </button>
        <button type="button" onClick={onClose} className="btn btn-ghost !min-h-10 !px-4 !py-2 !text-[10px]">
          Close ✕
        </button>
      </div>
    </motion.div>
  );
}

/* ───────────── Gallery ───────────── */
export function GalleryExperience() {
  const { settings, setSection } = useSettings();
  const collections = settings.memories.collections;

  const [photos, setPhotos] = useState<ViewPhoto[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [active, setActive] = useState<string>("all");
  const [lightIndex, setLightIndex] = useState<number | null>(null);
  const [slideshow, setSlideshow] = useState(false);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [liked, setLiked] = useState<string[]>([]);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadTarget, setUploadTarget] = useState<string>("");
  const [newCollection, setNewCollection] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const urlsRef = useRef<string[]>([]);

  const refresh = useCallback(async () => {
    const records = await listPhotos();
    urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    urlsRef.current = [];
    const list = records.map((r) => {
      const url = URL.createObjectURL(r.blob);
      urlsRef.current.push(url);
      return { ...r, url };
    });
    setPhotos(list);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await ensureSeeded();
        await refresh();
      } catch {
        /* IndexedDB unavailable: gallery stays empty but usable */
      } finally {
        if (!cancelled) setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
      urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [refresh]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(LIKED_KEY);
      if (stored) setLiked(JSON.parse(stored));
    } catch {
      /* ignore */
    }
  }, []);

  // Load shared heart counts from the server for the visible photos.
  useEffect(() => {
    const ids = photos.map((p) => p.id);
    if (ids.length === 0) return;
    fetch(`/api/reactions?ids=${encodeURIComponent(ids.join(","))}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { counts?: Record<string, number> } | null) => {
        if (data?.counts) setCounts((prev) => ({ ...prev, ...data.counts }));
      })
      .catch(() => {});
  }, [photos]);

  useEffect(() => {
    if (!uploadTarget && collections[0]) setUploadTarget(collections[0].id);
  }, [collections, uploadTarget]);

  const visible = active === "all" ? photos : photos.filter((p) => p.collectionId === active);

  const handleFiles = async (files: FileList | File[] | null) => {
    if (!files) return;
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (list.length === 0) return;
    setUploading(true);
    try {
      await uploadFiles(list, uploadTarget || collections[0]?.id || "c-favourites");
      await refresh();
    } finally {
      setUploading(false);
    }
  };

  const heart = async (id: string) => {
    if (liked.includes(id)) return;
    const next = [...liked, id];
    setLiked(next);
    try {
      localStorage.setItem(LIKED_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
    setCounts((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
    try {
      const res = await fetch("/api/reactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photoId: id }),
      });
      if (res.ok) {
        const data = (await res.json()) as { hearts: number };
        setCounts((c) => ({ ...c, [id]: data.hearts }));
      }
    } catch {
      /* keep optimistic local count */
    }
  };

  const saveCaption = async (id: string, caption: string) => {
    await updatePhoto(id, { caption });
    setPhotos((list) => list.map((p) => (p.id === id ? { ...p, caption } : p)));
  };

  const removePhoto = async (id: string) => {
    await deletePhoto(id);
    await refresh();
    setLightIndex(null);
  };

  const addCollection = () => {
    const name = newCollection.trim();
    if (!name) return;
    const id = uid("c");
    setSection("memories", { ...settings.memories, collections: [...collections, { id, name }] });
    setNewCollection("");
    setActive(id);
    setUploadTarget(id);
  };

  return (
    <main
      className="relative min-h-screen overflow-hidden bg-[#0a0508] pb-44 pt-24 text-[#f7efe4]"
      onDragEnter={(e) => {
        if (e.dataTransfer.types.includes("Files")) setDragging(true);
      }}
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes("Files")) e.preventDefault();
      }}
      onDragLeave={(e) => {
        if (e.currentTarget === e.target) setDragging(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void handleFiles(e.dataTransfer.files);
      }}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(231,166,184,0.18),transparent_55%),radial-gradient(ellipse_at_bottom_left,rgba(225,6,0,0.12),transparent_50%)]" />
      <FloatingParticles count={12} variant="petals" colors={["#e7a6b8", "#f6e7b0"]} />

      <AnimatePresence>
        {dragging && (
          <motion.div
            key="drop-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none fixed inset-0 z-[90] flex items-center justify-center border-4 border-dashed border-[color:var(--accent)] bg-black/80 backdrop-blur-sm"
          >
            <p className="font-display text-3xl italic sm:text-5xl">Drop our memories here 📸</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative mx-auto max-w-7xl px-5 sm:px-10">
        {/* Header */}
        <motion.header initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }}>
          <p className="label !text-[color:var(--accent)]">Website 03 · Our Private Gallery</p>
          <div className="mt-4 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <h1 className="font-display max-w-3xl text-4xl leading-[1.05] sm:text-6xl">
              Every frame, <span className="italic text-[color:var(--accent)]">a little universe.</span>
            </h1>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setSlideshow(true)}
                disabled={visible.length === 0}
                className="btn btn-accent"
              >
                ▶ Romantic slideshow
              </button>
              <button type="button" onClick={() => fileRef.current?.click()} className="btn btn-ghost" disabled={uploading}>
                {uploading ? "Uploading…" : "+ Upload photos"}
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  void handleFiles(e.target.files);
                  e.target.value = "";
                }}
              />
            </div>
          </div>
        </motion.header>

        {/* Drop zone + collection controls */}
        <div className="mt-10 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="glass group flex min-h-[9rem] flex-col items-center justify-center gap-2 rounded-[28px] border-dashed p-6 text-center transition-colors hover:bg-white/10"
          >
            <span className="text-3xl transition-transform group-hover:-translate-y-1">📥</span>
            <span className="font-semibold">Drag &amp; drop photos anywhere on this page</span>
            <span className="text-xs text-white/50">or click to browse · photos are optimised and saved in this browser</span>
          </button>

          <div className="glass flex flex-col justify-between gap-4 rounded-[28px] p-6">
            <div>
              <label htmlFor="upload-target" className="label">
                Upload into collection
              </label>
              <select
                id="upload-target"
                className="field mt-2"
                value={uploadTarget}
                onChange={(e) => setUploadTarget(e.target.value)}
              >
                {collections.map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#120a0e]">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                addCollection();
              }}
            >
              <input
                className="field"
                placeholder="New collection name…"
                value={newCollection}
                maxLength={40}
                onChange={(e) => setNewCollection(e.target.value)}
                aria-label="New collection name"
              />
              <button type="submit" className="btn btn-ghost shrink-0 !px-5" disabled={!newCollection.trim()}>
                Add
              </button>
            </form>
          </div>
        </div>

        {/* Collection tabs */}
        <div className="no-scrollbar mt-8 flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Photo collections">
          {[{ id: "all", name: "All memories" }, ...collections].map((c) => {
            const count = c.id === "all" ? photos.length : photos.filter((p) => p.collectionId === c.id).length;
            const isActive = active === c.id;
            return (
              <button
                key={c.id}
                role="tab"
                aria-selected={isActive}
                type="button"
                onClick={() => setActive(c.id)}
                className={`relative shrink-0 rounded-full border px-5 py-2.5 text-xs font-semibold tracking-wide transition-colors ${
                  isActive ? "border-transparent text-white" : "border-white/15 text-white/65 hover:text-white"
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="collection-pill"
                    className="absolute inset-0 -z-0 rounded-full bg-gradient-to-r from-[color:var(--accent)] to-[color:var(--accent-2)]"
                  />
                )}
                <span className="relative">
                  {c.name} <span className="ml-1 opacity-60">{count}</span>
                </span>
              </button>
            );
          })}
        </div>

        {/* Masonry */}
        <section className="mt-8" aria-label="Photo gallery">
          {!loaded ? (
            <div className="grid h-60 place-items-center text-white/40">Opening our album…</div>
          ) : visible.length === 0 ? (
            <div className="glass grid place-items-center rounded-[28px] p-14 text-center">
              <p className="font-display text-2xl italic">No photos in this collection yet.</p>
              <p className="mt-2 text-sm text-white/55">Drop some here, or pick another collection. 💗</p>
            </div>
          ) : (
            <div className="columns-2 gap-3 sm:gap-5 md:columns-3 xl:columns-4">
              {visible.map((p, i) => (
                <motion.figure
                  key={p.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.6, delay: Math.min(i * 0.04, 0.4) }}
                  className="group mb-3 break-inside-avoid overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] sm:mb-5"
                >
                  <button type="button" onClick={() => setLightIndex(i)} className="relative block w-full overflow-hidden" aria-label={`Open photo: ${p.caption}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={p.url}
                      alt={p.caption}
                      loading="lazy"
                      className="w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                    />
                    <span className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                  </button>
                  <figcaption className="flex items-start justify-between gap-3 p-3 sm:p-4">
                    <p className="font-display text-sm italic leading-snug text-white/85 sm:text-base">{p.caption || "Untitled memory"}</p>
                    <button
                      type="button"
                      onClick={() => heart(p.id)}
                      aria-label={liked.includes(p.id) ? "You hearted this" : "Heart this photo"}
                      className={`flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-all active:scale-90 ${
                        liked.includes(p.id) ? "border-[color:var(--accent)] bg-[color:var(--accent-soft)]" : "border-white/15 hover:bg-white/10"
                      }`}
                    >
                      <span aria-hidden>{liked.includes(p.id) ? "❤️" : "🤍"}</span>
                      <span className="tabular">{counts[p.id] ?? 0}</span>
                    </button>
                  </figcaption>
                </motion.figure>
              ))}
            </div>
          )}
        </section>

        <div className="mt-24">
          <MemoryTimeline entries={settings.memories.timeline} />
        </div>

        <footer className="mt-24 text-center text-xs text-white/40">
          Want your own photos here? Upload them above, or edit captions and collections in the{" "}
          <a href="/studio" className="underline underline-offset-4 hover:text-white">
            Studio
          </a>
          .
        </footer>
      </div>

      <AnimatePresence>
        {lightIndex !== null && visible[lightIndex] && (
          <Lightbox
            key="lightbox"
            photos={visible}
            index={lightIndex}
            onClose={() => setLightIndex(null)}
            onIndex={(i) => setLightIndex(i)}
            counts={counts}
            liked={liked}
            onHeart={heart}
            onCaption={saveCaption}
            onDelete={removePhoto}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {slideshow && visible.length > 0 && (
          <Slideshow
            key="slideshow"
            photos={visible}
            seconds={settings.memories.slideshowSeconds}
            onClose={() => setSlideshow(false)}
          />
        )}
      </AnimatePresence>

      <MusicPlayer />
    </main>
  );
}
