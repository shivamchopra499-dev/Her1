"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import { getTrack } from "@/lib/idb";
import { startAmbient, stopAmbient } from "@/lib/audio";

/**
 * Background music with play / pause.
 * - "ambient": a soft generated pad (works offline, no files needed)
 * - "custom": the audio file you uploaded in the Studio (stored in IndexedDB)
 */
export function MusicPlayer() {
  const { settings } = useSettings();
  const { musicMode, musicTitle } = settings.memories;
  const [playing, setPlaying] = useState(false);
  const [hasCustom, setHasCustom] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const urlRef = useRef<string | null>(null);

  useEffect(() => {
    getTrack()
      .then((t) => setHasCustom(!!t))
      .catch(() => setHasCustom(false));
  }, []);

  useEffect(() => {
    return () => {
      stopAmbient();
      audioRef.current?.pause();
      audioRef.current = null;
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    };
  }, []);

  const stopAll = () => {
    stopAmbient();
    audioRef.current?.pause();
  };

  const toggle = async () => {
    setError(null);
    if (playing) {
      stopAll();
      setPlaying(false);
      return;
    }
    try {
      if (musicMode === "custom" && hasCustom) {
        const track = await getTrack();
        if (!track) throw new Error("missing");
        if (urlRef.current) URL.revokeObjectURL(urlRef.current);
        urlRef.current = URL.createObjectURL(track.blob);
        const audio = new Audio(urlRef.current);
        audio.loop = true;
        audio.volume = 0.6;
        audioRef.current = audio;
        await audio.play();
      } else {
        startAmbient();
      }
      setPlaying(true);
    } catch {
      setError("Couldn't start the music. Try again.");
      setPlaying(false);
    }
  };

  const title = musicMode === "custom" && hasCustom ? musicTitle : "Midnight Lap (ambient)";

  return (
    <div className="fixed bottom-4 left-4 right-4 z-40 mx-auto flex max-w-sm items-center gap-3 rounded-full border border-white/15 bg-black/70 p-2 pl-3 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl sm:left-6 sm:right-auto">
      <button
        type="button"
        onClick={toggle}
        aria-label={playing ? "Pause background music" : "Play background music"}
        className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[color:var(--accent)] to-[color:var(--accent-2)] text-sm text-white shadow-[0_0_20px_var(--accent-glow)] transition-transform active:scale-90"
      >
        {playing ? "❚❚" : "▶"}
      </button>
      <div className="min-w-0 flex-1">
        <p className="label !text-[9px] !text-white/50">{playing ? "Now playing" : "Background music"}</p>
        <p className="truncate pr-2 text-sm font-semibold">{error ?? title}</p>
      </div>
      <div className="flex h-5 items-end gap-[3px] pr-3" aria-hidden>
        {[0, 1, 2, 3].map((i) => (
          <motion.span
            key={i}
            className="block w-[3px] rounded-full bg-[color:var(--accent)]"
            animate={playing ? { height: ["30%", "100%", "45%", "80%", "30%"] } : { height: "25%" }}
            transition={{ duration: 1.1 + i * 0.15, repeat: Infinity, ease: "easeInOut" }}
            style={{ height: "25%" }}
          />
        ))}
      </div>
    </div>
  );
}
