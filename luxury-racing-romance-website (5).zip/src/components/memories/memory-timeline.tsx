"use client";

import { motion } from "framer-motion";
import type { MemoryEntry } from "@/lib/defaults";
import { formatDate } from "@/lib/utils";

/** Vertical timeline of our memories, sorted by date. Edit entries in the Studio. */
export function MemoryTimeline({ entries }: { entries: MemoryEntry[] }) {
  const sorted = [...entries].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <section aria-label="Memory timeline" className="mx-auto max-w-4xl">
      <div className="text-center">
        <p className="label !text-[color:var(--accent)]">Our timeline</p>
        <h2 className="font-display mt-4 text-3xl sm:text-5xl">
          The story so far, <span className="italic text-white/70">one chapter at a time.</span>
        </h2>
      </div>

      <ol className="relative mt-16 ml-3 space-y-12 border-l border-white/15 sm:ml-6">
        {sorted.map((m, i) => (
          <motion.li
            key={m.id}
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.7, delay: i * 0.08 }}
            className="relative pl-8 sm:pl-12"
          >
            <span className="absolute -left-[7px] top-1.5 h-3.5 w-3.5 rounded-full bg-[color:var(--accent)] shadow-[0_0_18px_var(--accent-glow)] ring-4 ring-[#0a0508]" />
            <p className="label !text-[color:var(--accent)]">{formatDate(m.date)}</p>
            <h3 className="font-display mt-2 text-2xl sm:text-3xl">{m.title}</h3>
            <p className="mt-3 max-w-xl text-base leading-relaxed text-white/70">{m.text}</p>
          </motion.li>
        ))}
      </ol>
    </section>
  );
}
