"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

type Variant = "hearts" | "sparks" | "stars" | "petals";

type Props = {
  count?: number;
  variant?: Variant;
  colors?: string[];
  className?: string;
};

const GLYPHS: Record<Variant, string> = {
  hearts: "♥",
  sparks: "•",
  stars: "✦",
  petals: "❀",
};

/** Ambient floating particles. Rendered only after mount to avoid hydration mismatches. */
export function FloatingParticles({
  count = 18,
  variant = "hearts",
  colors = ["#ff7aa2", "#f6e7b0", "#ffffff"],
  className = "",
}: Props) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const items = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 10 + Math.random() * 20,
        duration: 9 + Math.random() * 10,
        delay: -Math.random() * 14,
        drift: (Math.random() - 0.5) * 140,
        color: colors[i % colors.length],
      })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [count, variant],
  );

  if (!mounted) return null;

  return (
    <div aria-hidden className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {items.map((p) => (
        <motion.span
          key={p.id}
          className="absolute bottom-[-40px] select-none leading-none"
          style={{
            left: `${p.left}%`,
            fontSize: p.size,
            color: p.color,
            textShadow: `0 0 12px ${p.color}`,
          }}
          initial={{ y: 0, opacity: 0 }}
          animate={{
            y: ["0vh", "-115vh"],
            x: [0, p.drift],
            opacity: [0, 0.9, 0.9, 0],
            rotate: [0, 180],
          }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "linear" }}
        >
          {GLYPHS[variant]}
        </motion.span>
      ))}
    </div>
  );
}
