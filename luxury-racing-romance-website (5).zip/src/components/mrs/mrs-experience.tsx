"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import { playChime } from "@/lib/audio";
import { paragraphs } from "@/lib/utils";
import { FloatingParticles } from "@/components/floating-particles";

const reveal = {
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] as const },
};

function Seal() {
  return (
    <div className="relative mx-auto flex h-24 w-24 items-center justify-center">
      <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full" aria-hidden>
        <defs>
          <path id="seal-circle" d="M 60,60 m -44,0 a 44,44 0 1,1 88,0 a 44,44 0 1,1 -88,0" />
        </defs>
        <motion.circle
          cx="60"
          cy="60"
          r="58"
          fill="none"
          stroke="#d4af37"
          strokeWidth="1.5"
          strokeDasharray="4 5"
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "60px 60px" }}
        />
        <text fill="#d4af37" fontSize="9.5" letterSpacing="3.2" fontFamily="Montserrat, sans-serif" fontWeight="600">
          <textPath href="#seal-circle">OFFICIALLY UNOFFICIALLY ✦ MRS CHOPRA ✦</textPath>
        </text>
      </svg>
      <span className="font-display gold-text text-2xl italic">MC</span>
    </div>
  );
}

function Crown({ active }: { active: boolean }) {
  return (
    <svg viewBox="0 0 200 140" className="mx-auto h-40 w-56 drop-shadow-[0_0_30px_rgba(212,175,55,0.55)] sm:h-52 sm:w-72" aria-hidden>
      <defs>
        <linearGradient id="crown-gold" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stopColor="#8a6a2c" />
          <stop offset="0.5" stopColor="#f6e7b0" />
          <stop offset="1" stopColor="#b8862b" />
        </linearGradient>
      </defs>
      {active && (
        <>
          <motion.path
            d="M 20 110 L 30 40 L 70 80 L 100 20 L 130 80 L 170 40 L 180 110 Z"
            fill="url(#crown-gold)"
            stroke="#f6e7b0"
            strokeWidth="2"
            strokeLinejoin="round"
            initial={{ pathLength: 0, fillOpacity: 0 }}
            animate={{ pathLength: 1, fillOpacity: 1 }}
            transition={{ duration: 1.8, ease: "easeInOut" }}
          />
          <motion.rect
            x="20"
            y="112"
            width="160"
            height="14"
            rx="4"
            fill="url(#crown-gold)"
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            transition={{ delay: 1.6, duration: 0.7 }}
          />
          {[
            { cx: 30, cy: 40, c: "#9b1d3f", d: 1.9 },
            { cx: 100, cy: 20, c: "#2e7d5b", d: 2.1 },
            { cx: 170, cy: 40, c: "#9b1d3f", d: 2.3 },
          ].map((j) => (
            <motion.circle
              key={j.cx}
              cx={j.cx}
              cy={j.cy}
              r="6"
              fill={j.c}
              stroke="#f6e7b0"
              strokeWidth="1.5"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: j.d, type: "spring", stiffness: 260 }}
              style={{ transformOrigin: `${j.cx}px ${j.cy}px` }}
            />
          ))}
        </>
      )}
    </svg>
  );
}

export function MrsExperience() {
  const { settings, progress, markDone } = useSettings();
  const m = settings.mrs;
  const claimed = progress.done.includes("mrs:crown");

  const [reply, setReply] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [crownOpen, setCrownOpen] = useState(claimed);

  const claimCrown = () => {
    setCrownOpen(true);
    markDone("mrs:crown");
    playChime();
  };

  const sendReply = async () => {
    const message = reply.trim();
    if (!message || status === "sending") return;
    setStatus("sending");
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      if (!res.ok) throw new Error("failed");
      setStatus("sent");
      setReply("");
    } catch {
      setStatus("error");
    }
  };

  return (
    <main className="relative overflow-hidden bg-[#070203] text-[#f7efe4]">
      {/* ─── Hero ─── */}
      <section className="relative flex min-h-[100svh] flex-col items-center justify-center px-6 pb-20 pt-28 text-center">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#6b1636_0%,#2a0712_42%,#070203_100%)]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#070203] to-transparent" />
        <FloatingParticles count={26} variant="sparks" colors={["#d4af37", "#f6e7b0", "#e7a6b8"]} />

        <motion.p
          initial={{ opacity: 0, letterSpacing: "0.1em" }}
          animate={{ opacity: 1, letterSpacing: "0.34em" }}
          transition={{ duration: 1.6 }}
          className="label relative !text-[#d4af37]"
        >
          Private Edition · No. 01 of 01
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 40, filter: "blur(10px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 1.4, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="font-display relative mt-8 max-w-4xl text-5xl leading-[1.02] italic sm:text-7xl lg:text-[6.5rem]"
        >
          {m.heroLine}
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 1.2 }}
          className="relative mt-10 flex flex-col items-center gap-4"
        >
          <div className="h-px w-40 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent" />
          <p className="font-f1 gold-text text-2xl font-black tracking-[0.42em] sm:text-4xl">
            {m.title} <span className="not-italic">👑</span>
          </p>
        </motion.div>

        <motion.a
          href="#certificate"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-8 flex flex-col items-center gap-2 text-[10px] tracking-[0.3em] text-white/50"
        >
          SCROLL
          <motion.span
            className="block h-8 w-px bg-gradient-to-b from-[#d4af37] to-transparent"
            animate={{ scaleY: [0.3, 1, 0.3], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.a>
      </section>

      {/* ─── Certificate ─── */}
      <section id="certificate" className="relative px-6 py-28 sm:px-10">
        <motion.div {...reveal} className="mx-auto max-w-3xl">
          <div className="rounded-[34px] border border-[#d4af37]/60 p-2 shadow-[0_40px_120px_-30px_rgba(212,175,55,0.35)]">
            <div className="rounded-[26px] border border-[#d4af37]/30 bg-[linear-gradient(160deg,#241018_0%,#0d0508_100%)] px-6 py-12 text-center sm:px-14 sm:py-16">
              <p className="label !text-[#d4af37]">Certificate · Official Unofficial Registry</p>
              <h2 className="font-display gold-text mt-6 text-3xl sm:text-5xl">{m.certificateTitle}</h2>
              <p className="mt-8 font-display text-base italic text-white/60">This certifies that</p>
              <p className="font-f1 mt-3 text-3xl font-black tracking-[0.12em] sm:text-5xl">PARTHIBA</p>
              <p className="mx-auto mt-8 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">{m.certificateBody}</p>

              <div className="mt-12 grid items-center gap-8 border-t border-[#d4af37]/20 pt-10 sm:grid-cols-3">
                <div>
                  <p className="label !text-[#d4af37]/80">Date</p>
                  <p className="mt-2 font-display text-base italic">{m.certificateDate}</p>
                </div>
                <Seal />
                <div>
                  <p className="label !text-[#d4af37]/80">Issued by</p>
                  <p className="mt-2 font-display text-base italic">{m.certificateIssuer}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ─── Special message ─── */}
      <section className="relative px-6 py-24 sm:px-10">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#d4af37]/40 to-transparent" />
        <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-[1fr_1.4fr] lg:items-start">
          <motion.div {...reveal}>
            <p className="label !text-[#d4af37]">From Mr. Chopra, with love</p>
            <h2 className="font-display mt-5 text-4xl leading-tight sm:text-6xl">{m.specialTitle}</h2>
            <div className="mt-8 h-px w-24 bg-[#d4af37]" />
          </motion.div>
          <div className="space-y-6">
            {paragraphs(m.specialMessage).map((para, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.8, delay: i * 0.15 }}
                className="font-display text-xl leading-relaxed text-white/85 sm:text-2xl"
              >
                {para}
              </motion.p>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Crown ─── */}
      <section className="relative px-6 py-28 text-center sm:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(212,175,55,0.14),transparent_60%)]" />
        <motion.div {...reveal} className="relative mx-auto max-w-3xl">
          <p className="label !text-[#d4af37]">The royal moment</p>
          <h2 className="font-display mt-5 text-4xl sm:text-6xl">{m.crownTitle}</h2>

          {!crownOpen ? (
            <motion.button
              type="button"
              onClick={claimCrown}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              className="btn btn-gold mt-12 !px-10 !py-5 !text-sm"
            >
              👑 Claim Your Crown
            </motion.button>
          ) : (
            <div className="mt-12">
              <FloatingParticles count={22} variant="sparks" colors={["#d4af37", "#f6e7b0", "#ffffff"]} />
              <Crown active />
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2.2, duration: 1 }}
                className="paper relative mx-auto mt-14 max-w-2xl rounded-[28px] p-8 text-left sm:p-14"
              >
                <p className="label !text-[#8a6a2c]">A personalised love letter</p>
                <div className="mt-6 space-y-5">
                  {paragraphs(m.crownLetter).map((para, i) => (
                    <motion.p
                      key={i}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 2.6 + i * 0.5 }}
                      className="font-display whitespace-pre-line text-lg leading-relaxed sm:text-xl"
                    >
                      {para}
                    </motion.p>
                  ))}
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </section>

      {/* ─── Reply ─── */}
      <section className="relative px-6 pb-32 sm:px-10">
        <motion.div {...reveal} className="glass mx-auto max-w-2xl rounded-[28px] p-7 sm:p-10">
          <p className="label !text-[#d4af37]">Mrs. Chopra&apos;s reply</p>
          <p className="font-display mt-4 text-xl italic text-white/85">{m.replyPrompt}</p>
          <textarea
            className="field mt-6 min-h-[120px]"
            placeholder="Likho kuch bhi... Mr. Chopra ko sab padhna pasand hai."
            maxLength={500}
            value={reply}
            onChange={(e) => {
              setReply(e.target.value);
              if (status !== "idle" && status !== "sending") setStatus("idle");
            }}
            aria-label="Write a reply to Mr. Chopra"
          />
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-white/50" role="status">
              {status === "sent" && "Sent to Mr. Chopra's inbox 💌"}
              {status === "error" && "Couldn't send right now. Check the connection and try again."}
              {status === "idle" && `${reply.length}/500`}
              {status === "sending" && "Sending…"}
            </p>
            <button type="button" onClick={sendReply} disabled={!reply.trim() || status === "sending"} className="btn btn-gold">
              Send with love 💌
            </button>
          </div>
        </motion.div>
      </section>

      <footer className="border-t border-white/10 px-6 py-10 text-center text-xs text-white/40">
        Officially unofficially yours · Mr. Chopra ❤️
      </footer>
    </main>
  );
}
