"use client";

import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";

type Props = {
  href: string;
  className?: string;
  children: ReactNode;
  /** Duration of the fade to black before navigating, in ms */
  duration?: number;
};

/** A button that fades the whole screen to black, then navigates. */
export function FadeLink({ href, className = "btn btn-accent", children, duration = 1000 }: Props) {
  const router = useRouter();
  const [fading, setFading] = useState(false);

  return (
    <>
      <button
        type="button"
        className={className}
        onClick={() => {
          if (fading) return;
          setFading(true);
          window.setTimeout(() => router.push(href), duration);
        }}
      >
        {children}
      </button>
      {typeof document !== "undefined" &&
        createPortal(
          <AnimatePresence>
            {fading && (
              <motion.div
                key="fade"
                className="fixed inset-0 z-[200] bg-black"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: duration / 1000, ease: "easeInOut" }}
              />
            )}
          </AnimatePresence>,
          document.body,
        )}
    </>
  );
}
