"use client";

import Link from "next/link";
import type { ReactElement } from "react";
import { motion } from "framer-motion";
import { EXPERIENCES, type Experience } from "@/lib/defaults";
import { cn } from "@/lib/utils";

/* ─── Unique, animated thumbnails: one tiny universe per card ─── */

function RaceThumb() {
  return (
    <div className="carbon absolute inset-0 overflow-hidden">
      <div className="absolute inset-x-0 top-[18%] flex justify-center gap-2">
        {[0, 1, 2, 3, 4].map((i) => (
          <motion.span
            key={i}
            className="h-3.5 w-3.5 rounded-full bg-[#2a0000]"
            animate={{ backgroundColor: ["#2a0000", "#ff1e1e", "#ff1e1e", "#2a0000"], boxShadow: ["0 0 0 #0000", "0 0 14px #ff1e1e", "0 0 14px #ff1e1e", "0 0 0 #0000"] }}
            transition={{ duration: 3.2, repeat: Infinity, delay: i * 0.25, times: [0, 0.2, 0.7, 1] }}
          />
        ))}
      </div>
      <motion.div
        className="absolute inset-x-0 bottom-[30%] h-[3px] bg-[linear-gradient(90deg,transparent,#fff,transparent)] opacity-40"
        animate={{ x: ["-100%", "100%"] }}
        transition={{ duration: 1.4, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute bottom-[18%] left-0 text-4xl"
        animate={{ x: ["-20%", "120%"] }}
        transition={{ duration: 3.6, repeat: Infinity, ease: "easeIn" }}
      >
        <svg viewBox="0 0 120 50" className="h-14 w-28 drop-shadow-[0_0_12px_rgba(225,6,0,.8)]">
          <path d="M8 30 Q10 20 26 18 L44 14 Q60 8 78 16 L100 22 Q112 26 112 34 L112 38 L8 38 Z" fill="#e10600" />
          <rect x="30" y="34" width="14" height="8" rx="2" fill="#111" />
          <rect x="82" y="34" width="14" height="8" rx="2" fill="#111" />
          <text x="60" y="30" fontSize="7" fill="#fff" textAnchor="middle" fontFamily="Orbitron, sans-serif" fontWeight="900">MRS CHOPRA</text>
        </svg>
      </motion.div>
    </div>
  );
}

function MrsThumb() {
  return (
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,#6b1630_0%,#2a0712_55%,#0b0306_100%)]">
      <motion.div
        className="absolute left-1/2 top-1/2 h-36 w-36 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#d4af37]/50"
        style={{ borderStyle: "dashed" }}
        animate={{ rotate: 360 }}
        transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute left-1/2 top-1/2 flex h-20 w-20 -translate-x-1/2 -translate-y-1/2 items-center justify-center text-5xl"
        animate={{ y: ["-50%", "-54%", "-50%"], filter: ["drop-shadow(0 0 6px #d4af37)", "drop-shadow(0 0 18px #f6e7b0)", "drop-shadow(0 0 6px #d4af37)"] }}
        transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
      >
        👑
      </motion.div>
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="absolute h-1.5 w-1.5 rounded-full bg-[#f6e7b0]"
          style={{ left: `${20 + i * 28}%`, top: `${25 + (i % 2) * 50}%` }}
          animate={{ opacity: [0.1, 1, 0.1], scale: [0.6, 1.3, 0.6] }}
          transition={{ duration: 2.4, repeat: Infinity, delay: i * 0.5 }}
        />
      ))}
    </div>
  );
}

function MemoriesThumb() {
  const cards = [
    { c: "from-[#e7a6b8] to-[#7a2a47]", r: -10, x: "-18%", delay: 0 },
    { c: "from-[#d4af37] to-[#5a3b0a]", r: 6, x: "14%", delay: 0.8 },
    { c: "from-[#f3c4d2] to-[#8e3b58]", r: -2, x: "-2%", delay: 1.6 },
  ];
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(circle_at_30%_20%,#4a1028,#120409)]">
      {cards.map((card, i) => (
        <motion.div
          key={i}
          className={cn("absolute h-[62%] w-[38%] rounded-md border-[6px] border-white bg-gradient-to-br shadow-2xl", card.c)}
          style={{ rotate: card.r, x: card.x }}
          animate={{ y: ["0%", "-8%", "0%"], rotate: [card.r, card.r + 4, card.r] }}
          transition={{ duration: 4.5, repeat: Infinity, delay: card.delay, ease: "easeInOut" }}
        >
          <div className="absolute inset-x-2 bottom-1 h-2 rounded-sm bg-white/30" />
        </motion.div>
      ))}
    </div>
  );
}

function DoraemonThumb() {
  return (
    <div className="sky-bg absolute inset-0 overflow-hidden">
      {[
        { t: "8%", d: 14, s: 1 },
        { t: "40%", d: 20, s: 0.7 },
        { t: "68%", d: 26, s: 0.55 },
      ].map((c, i) => (
        <motion.svg
          key={i}
          viewBox="0 0 120 50"
          className="absolute w-28 fill-white/95"
          style={{ top: c.t, scale: c.s }}
          initial={{ x: "-40%" }}
          animate={{ x: ["-40%", "140%"] }}
          transition={{ duration: c.d, repeat: Infinity, ease: "linear", delay: -i * 4 }}
        >
          <circle cx="30" cy="30" r="16" />
          <circle cx="54" cy="22" r="20" />
          <circle cx="82" cy="30" r="15" />
          <rect x="20" y="30" width="72" height="16" rx="8" />
        </motion.svg>
      ))}
      <motion.div
        className="absolute bottom-[18%] left-1/2 h-12 w-12 -translate-x-1/2 origin-top rounded-full bg-[radial-gradient(circle_at_35%_30%,#fff6a8,#ffd23f_45%,#c98a00)] shadow-[0_0_20px_rgba(255,210,63,.8)]"
        animate={{ rotate: [-14, 14, -14] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}

function LettersThumb() {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(circle_at_50%_0%,#3a2630,#0f0a0d_70%)]">
      <div className="relative h-[54%] w-[64%]">
        <motion.div
          className="absolute inset-x-0 top-0 h-[48%] origin-top rounded-t-md bg-gradient-to-b from-[#f2dfb8] to-[#e4c995] [clip-path:polygon(0_0,100%_0,50%_100%)]"
          animate={{ rotateX: [0, 0, 170, 170, 0] }}
          transition={{ duration: 4, repeat: Infinity, times: [0, 0.35, 0.55, 0.85, 1], ease: "easeInOut" }}
          style={{ transformPerspective: 400 }}
        />
        <div className="kraft absolute inset-0 rounded-md shadow-[0_10px_30px_rgba(0,0,0,.5)]" />
        <motion.div
          className="absolute left-1/2 top-[44%] flex h-9 w-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#f08a9c,#8a0f2c)] text-sm shadow-lg"
          animate={{ scale: [1, 1.12, 1] }}
          transition={{ duration: 1.6, repeat: Infinity }}
        >
          ❤
        </motion.div>
      </div>
    </div>
  );
}

function ArcadeThumb() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-[linear-gradient(180deg,#12001f,#1d0030)]">
      <motion.div
        className="arcade-grid absolute inset-x-[-50%] bottom-[-10%] h-[70%] origin-bottom [transform:perspective(200px)_rotateX(60deg)]"
        animate={{ backgroundPositionY: ["0px", "44px"] }}
        transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
      />
      <div className="absolute inset-x-0 top-[22%] text-center font-f1 text-xl font-black text-[#ff3dbb] [text-shadow:0_0_16px_#ff3dbb]">
        <motion.span animate={{ scale: [1, 1.12, 1] }} transition={{ duration: 1.5, repeat: Infinity }} className="inline-block">
          ♥ 1UP
        </motion.span>
      </div>
      <div className="absolute inset-x-0 bottom-[22%] text-center text-[10px] font-bold tracking-[0.3em] text-[#5ff0ff] blink">
        INSERT COIN
      </div>
    </div>
  );
}

const THUMBS: Record<string, () => ReactElement> = {
  race: RaceThumb,
  mrs: MrsThumb,
  memories: MemoriesThumb,
  doraemon: DoraemonThumb,
  letters: LettersThumb,
  arcade: ArcadeThumb,
};

function ExperienceCard({ item, index }: { item: Experience; index: number }) {
  const Thumb = THUMBS[item.key];
  return (
    <motion.div
      initial={{ opacity: 0, y: 48, filter: "blur(8px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay: (index % 3) * 0.12, ease: [0.22, 1, 0.36, 1] }}
      className="h-full"
    >
      <Link
        href={item.href}
        className="group relative flex h-full flex-col overflow-hidden rounded-[28px] border border-white/10 bg-[#0c0c0f] transition-all duration-500 hover:-translate-y-2 hover:border-[color:var(--card)] hover:shadow-[0_30px_80px_-20px_var(--card)]"
        style={{ ["--card" as string]: item.accent }}
      >
        <div className="relative aspect-[16/10] overflow-hidden">
          <Thumb />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0f] via-transparent to-transparent" />
          <span className="absolute left-4 top-4 rounded-full bg-black/50 px-3 py-1 text-[10px] font-bold tracking-[0.2em] text-white/80 backdrop-blur">
            {item.tag}
          </span>
        </div>
        <div className="flex flex-1 flex-col gap-3 p-6">
          <div className="flex items-start justify-between gap-3">
            <h3 className="font-display text-2xl leading-tight text-white">{item.title}</h3>
            <span className="text-2xl transition-transform duration-500 group-hover:scale-125">{item.emoji}</span>
          </div>
          <p className="text-sm leading-relaxed text-white/65">{item.tagline}</p>
          <div className="mt-auto flex items-center gap-2 pt-3 text-[11px] font-bold uppercase tracking-[0.22em] text-white/80">
            <span className="h-[2px] w-6 rounded-full transition-all duration-500 group-hover:w-12" style={{ background: item.accent }} />
            Enter world
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export function ExperienceCards() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
      {EXPERIENCES.map((item, i) => (
        <ExperienceCard key={item.key} item={item} index={i} />
      ))}
    </div>
  );
}
