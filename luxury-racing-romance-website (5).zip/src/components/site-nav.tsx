"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { EXPERIENCES } from "@/lib/defaults";
import { useSettings } from "@/lib/store";
import { cn } from "@/lib/utils";

/** The one persistent navigation for the whole universe. Also records visited worlds. */
export function SiteNav() {
  const pathname = usePathname();
  const { markVisited, progress } = useSettings();
  const [open, setOpen] = useState(false);

  const isExperience = EXPERIENCES.some((e) => e.href === pathname);

  useEffect(() => {
    if (isExperience) markVisited(pathname);
  }, [pathname, isExperience, markVisited]);

  useEffect(() => setOpen(false), [pathname]);

  if (pathname === "/finale") return null;

  const explored = EXPERIENCES.filter((e) => progress.visited.includes(e.href)).length;

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="glass-strong mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:mt-3 lg:h-14 lg:rounded-full lg:px-5">
        <Link href="/" className="group flex items-center gap-2" aria-label="Mrs. Chopra home">
          <span className="font-f1 text-[0.8rem] font-black tracking-[0.18em] sm:text-sm">
            MRS<span className="text-[color:var(--accent)]">.</span> CHOPRA
          </span>
          <span className="hidden text-[10px] tracking-[0.25em] text-white/50 xl:inline">· THE LOVE UNIVERSE</span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          {EXPERIENCES.map((e) => {
            const active = pathname === e.href;
            return (
              <Link
                key={e.href}
                href={e.href}
                className={cn(
                  "relative whitespace-nowrap rounded-full px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors",
                  active ? "text-white" : "text-white/60 hover:text-white",
                )}
              >
                <span className="mr-1">{e.emoji}</span>
                {e.short}
                {active && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-x-3 -bottom-0.5 h-[2px] rounded-full bg-[color:var(--accent)]"
                  />
                )}
              </Link>
            );
          })}
          <Link
            href="/studio"
            className={cn(
              "ml-2 rounded-full border border-white/20 px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors hover:bg-white/10",
              pathname === "/studio" && "bg-white/10 text-white",
            )}
          >
            ✏️ Studio
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <span className="hidden text-[10px] font-semibold tracking-[0.2em] text-white/50 md:inline lg:hidden">
            {explored}/{EXPERIENCES.length} WORLDS
          </span>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            className="btn btn-ghost !min-h-10 !px-4 !py-2 lg:hidden"
          >
            {open ? "Close" : "Menu"}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            key="mobile-menu"
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.3 }}
            className="glass-strong mx-3 mt-2 rounded-3xl p-3 lg:hidden"
          >
            <ul className="grid grid-cols-1 gap-1 sm:grid-cols-2">
              {EXPERIENCES.map((e, i) => (
                <motion.li
                  key={e.href}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    href={e.href}
                    className={cn(
                      "flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10",
                      pathname === e.href && "bg-white/10",
                    )}
                  >
                    <span className="text-xl">{e.emoji}</span>
                    <span>{e.title}</span>
                  </Link>
                </motion.li>
              ))}
              <li>
                <Link
                  href="/studio"
                  className="flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10"
                >
                  <span className="text-xl">✏️</span>
                  <span>Personalise the Universe</span>
                </Link>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
