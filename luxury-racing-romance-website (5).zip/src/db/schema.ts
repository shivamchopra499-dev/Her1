import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Server-side persistence for the Love Universe.
 * - photoReactions: shared heart counts for each gallery photo.
 * - loveNotes: replies Mrs. Chopra writes back to Mr. Chopra (visible in the Studio inbox).
 */
export const photoReactions = pgTable("photo_reactions", {
  photoId: text("photo_id").primaryKey(),
  hearts: integer("hearts").notNull().default(0),
});

export const loveNotes = pgTable("love_notes", {
  id: serial("id").primaryKey(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
