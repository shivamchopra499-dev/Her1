"use client";

/* ─────────────────────────────────────────────────────────────
   Web Audio helpers: a soft generated ambient pad (no external
   files needed), an engine-rev sound and a small chime.
   ───────────────────────────────────────────────────────────── */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sources: AudioScheduledSourceNode[] = [];
let ambientOn = false;

function getCtx(): AudioContext {
  if (!ctx) {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new Ctor();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function isAmbientOn(): boolean {
  return ambientOn;
}

export function startAmbient(): void {
  if (ambientOn) return;
  const c = getCtx();
  const out = c.createGain();
  out.gain.setValueAtTime(0.0001, c.currentTime);
  out.gain.exponentialRampToValueAtTime(0.16, c.currentTime + 2.5);
  out.connect(c.destination);

  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 1100;
  filter.connect(out);

  // Cmaj9-ish chord, slow breathing LFO on each voice.
  const chord = [130.81, 164.81, 196.0, 246.94, 329.63, 392.0];
  const created: AudioScheduledSourceNode[] = [];
  chord.forEach((freq, i) => {
    const osc = c.createOscillator();
    osc.type = i % 2 === 0 ? "triangle" : "sine";
    osc.frequency.value = freq;
    const voice = c.createGain();
    voice.gain.value = 0.14 / (i + 1);
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.04 + i * 0.017;
    const lfoDepth = c.createGain();
    lfoDepth.gain.value = 0.05 / (i + 1);
    lfo.connect(lfoDepth);
    lfoDepth.connect(voice.gain);
    osc.connect(voice);
    voice.connect(filter);
    osc.start();
    lfo.start();
    created.push(osc, lfo);
  });

  master = out;
  sources = created;
  ambientOn = true;
}

export function stopAmbient(): void {
  if (!ambientOn || !ctx || !master) return;
  const c = ctx;
  const out = master;
  const toStop = sources;
  out.gain.cancelScheduledValues(c.currentTime);
  out.gain.setValueAtTime(out.gain.value, c.currentTime);
  out.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 1.2);
  window.setTimeout(() => {
    toStop.forEach((s) => {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    });
    out.disconnect();
  }, 1300);
  master = null;
  sources = [];
  ambientOn = false;
}

/** Engine rev: a rising, wobbling sawtooth through a low-pass filter. */
export function playEngineRev(): void {
  const c = getCtx();
  const t = c.currentTime;
  const osc = c.createOscillator();
  osc.type = "sawtooth";
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 700;
  filter.Q.value = 3;
  const gain = c.createGain();
  osc.connect(filter);
  filter.connect(gain);
  gain.connect(c.destination);

  osc.frequency.setValueAtTime(55, t);
  osc.frequency.exponentialRampToValueAtTime(240, t + 0.9);
  osc.frequency.exponentialRampToValueAtTime(110, t + 1.4);
  osc.frequency.exponentialRampToValueAtTime(420, t + 2.2);
  osc.frequency.exponentialRampToValueAtTime(170, t + 2.8);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(0.22, t + 0.2);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 3);
  osc.start(t);
  osc.stop(t + 3.05);
}

/** Two-note chime for correct answers / checkpoints. */
export function playChime(): void {
  const c = getCtx();
  [880, 1320].forEach((freq, i) => {
    const t = c.currentTime + i * 0.12;
    const osc = c.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const gain = c.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(t);
    osc.stop(t + 0.75);
  });
}
