/* ─────────────────────────────────────────────────────────────
   Everything personal lives here. These are the DEFAULT words of
   the universe. Every value can be edited from /studio and is saved
   in the browser (localStorage), so no code editing is ever needed.
   ───────────────────────────────────────────────────────────── */

export type ThemeId = "racing" | "romance" | "doraemon";

export const THEMES: { id: ThemeId; name: string; blurb: string; swatch: [string, string] }[] = [
  {
    id: "racing",
    name: "Ferrari Racing Red",
    blurb: "Carbon black, red starting lights, pole position energy.",
    swatch: ["#e10600", "#ff4b3e"],
  },
  {
    id: "romance",
    name: "Burgundy Romance",
    blurb: "Soft rose, champagne gold, candle-lit glass.",
    swatch: ["#e7a6b8", "#d4af37"],
  },
  {
    id: "doraemon",
    name: "Doraemon Sky",
    blurb: "Sky blue clouds, bell-yellow sparks, gadget magic.",
    swatch: ["#2ea3ff", "#ffd23f"],
  },
];

export type Experience = {
  key: string;
  href: string;
  title: string;
  short: string;
  tagline: string;
  emoji: string;
  accent: string;
  tag: string;
};

export const EXPERIENCES: Experience[] = [
  {
    key: "race",
    href: "/race",
    title: "The Race of Love",
    short: "Race",
    tagline: "Pole position, checkpoints and a finish line made of you.",
    emoji: "🏎️",
    accent: "#e10600",
    tag: "Website 01",
  },
  {
    key: "mrs",
    href: "/mrs-chopra",
    title: "The Mrs. Chopra Experience",
    short: "Madam Ji",
    tagline: "A luxury love certificate, a royal title and a crown to claim.",
    emoji: "💍",
    accent: "#d4af37",
    tag: "Website 02",
  },
  {
    key: "memories",
    href: "/memories",
    title: "Our Private Gallery",
    short: "Gallery",
    tagline: "Photo collections, a memory timeline and a slideshow of us.",
    emoji: "📸",
    accent: "#e7a6b8",
    tag: "Website 03",
  },
  {
    key: "doraemon",
    href: "/doraemon",
    title: "Doraemon's Secret World",
    short: "Doraemon",
    tagline: "Gift boxes, anywhere doors and nicknames for Golu Molu.",
    emoji: "💙",
    accent: "#2ea3ff",
    tag: "Website 04",
  },
  {
    key: "letters",
    href: "/letters",
    title: "Open When You Miss Me",
    short: "Letters",
    tagline: "Seven sealed envelopes for every mood you might be having.",
    emoji: "💌",
    accent: "#c08a5b",
    tag: "Website 05",
  },
  {
    key: "arcade",
    href: "/arcade",
    title: "The Love Arcade",
    short: "Arcade",
    tagline: "Five mini-games. Clear them all to unlock a secret surprise.",
    emoji: "🎮",
    accent: "#ff3dbb",
    tag: "Website 06",
  },
];

export type Checkpoint = { title: string; message: string };
export type MemoryEntry = { id: string; date: string; title: string; text: string };
export type Collection = { id: string; name: string };
export type Gift = { id: string; emoji: string; name: string; message: string };
export type Letter = { id: string; emoji: string; title: string; body: string; signature: string };
export type QuizQuestion = { q: string; options: string[]; answer: number };

export type Settings = {
  theme: ThemeId;
  race: {
    welcomeTitle: string;
    subtitle: string;
    polePosition: string;
    checkpoints: Checkpoint[];
    finishLine: string;
  };
  mrs: {
    heroLine: string;
    title: string;
    certificateTitle: string;
    certificateBody: string;
    certificateDate: string;
    certificateIssuer: string;
    specialTitle: string;
    specialMessage: string;
    crownTitle: string;
    crownLetter: string;
    replyPrompt: string;
  };
  memories: {
    collections: Collection[];
    timeline: MemoryEntry[];
    musicMode: "ambient" | "custom";
    musicTitle: string;
    slideshowSeconds: number;
  };
  doraemon: {
    alert: string;
    nicknames: string[];
    funnyMessages: string[];
    affectionateMessages: string[];
    gifts: Gift[];
  };
  letters: Letter[];
  arcade: {
    password: string;
    hints: string[];
    mrQuiz: QuizQuestion[];
    romanticQuiz: QuizQuestion[];
    hiddenMessages: string[];
  };
  finale: {
    lines: string[];
    signoff: string;
  };
};

export const DEFAULT_SETTINGS: Settings = {
  theme: "racing",

  race: {
    welcomeTitle: "WELCOME TO THE WORLD OF MRS. CHOPRA",
    subtitle: "A special race. One destination. Forever with you.",
    polePosition: "PARTHIBA, YOU ARE MY POLE POSITION.",
    checkpoints: [
      {
        title: "Lights Out",
        message:
          "Jab tum pehli baar mere saamne aayi thi, mujhe laga race ka start ho gaya. Heartbeat ne bhi ready hone mein thoda time liya. 💗",
      },
      {
        title: "First Overtake",
        message:
          "Tumne bina DRS ke mujhe overtake kar liya tha, aur main aaj tak wahi lap repeat kar raha hoon. 😌",
      },
      {
        title: "The Rainy Lap",
        message:
          "Ek baarish wali shaam, aur tumhari hansi. Us ek lap mein poori duniya slow motion mein chal rahi thi.",
      },
      {
        title: "Pit Stop of Love",
        message:
          "Jab bhi main thaka hota hoon, tumhari ek call hi mera pit stop hai. Fuel full, mood full, bakwaas zero.",
      },
      {
        title: "Speed Trap",
        message:
          "Warning: Is ladki ki cuteness speed limit cross kar rahi hai. Traffic police bhi tumse pyaar kar baithegi.",
      },
      {
        title: "Final Corner",
        message:
          "Har race ka ek hi goal hai: tum. Chahe jitne laps ho jaayein, meri finish line hamesha tumhare paas hai.",
      },
    ],
    finishLine: "Race completed. Destination: YOU. 🏁",
  },

  mrs: {
    heroLine: "Officially unofficially, Mrs. Chopra.",
    title: "MADAM JI",
    certificateTitle: "Digital Love Certificate",
    certificateBody:
      "This certifies that PARTHIBA is, officially unofficially, the one and only Mrs. Chopra, with full rights to tease, to be loved endlessly, and to be right about everything (even when she isn't).",
    certificateDate: "Valid forever ❤️",
    certificateIssuer: "Mr. Chopra, Chief Pyaar Officer",
    specialTitle: "A special message from Mr. Chopra",
    specialMessage:
      "Malkin Ji, tumhare bina meri duniya ek bina brake wali car jaisi thi: fast, loud, aur bilkul bhi safe nahi.\n\nTum aayi aur sab balanced ho gaya. Tum mujhe roz thoda better insaan banati ho, aur haan, tum jitna chaho utna mujhe tease kar sakti ho. Main sab sun lunga... pehle thoda drama karunga, phir maan jaunga. 😌",
    crownTitle: "Claim Your Crown",
    crownLetter:
      "Madam Ji,\n\nAaj se tum sirf meri girlfriend nahi ho. Tum meri Mrs. Chopra ho. Officially nahi, unofficially bhi nahi. Bas seedha sa sach, jaise tum meri zindagi ki sabse achhi cheez ho.\n\nTumne mujhe sikhaya hai ki race sirf speed se nahi, saath se jeeti jaati hai. Har lap mein tum saath thi: kabhi chai ke saath, kabhi meri bakwaas ke saath, kabhi mere saare mood swings ke saath.\n\nIsliye aaj, is crown ke saath, bas itna kehna chahta hoon: mere saath chalo. Forever. Pole position tumhari hai.\n\nYours, always,\nMr. Chopra 👑",
    replyPrompt: "Mrs. Chopra, Mr. Chopra ko kuch likhna hai? Likh do, main padh lunga.",
  },

  memories: {
    collections: [
      { id: "c-favourites", name: "Our Favourites" },
      { id: "c-trips", name: "Road Trips" },
      { id: "c-everyday", name: "Everyday Magic" },
    ],
    timeline: [
      {
        id: "m1",
        date: "2024-02-14",
        title: "The First Hello",
        text: "Ek chhota sa message, aur pata nahi tha ki yeh kahani itni badi ho jaayegi. (Sample memory: edit me in the Studio.)",
      },
      {
        id: "m2",
        date: "2024-05-20",
        title: "The First Long Drive",
        text: "Windows down, music loud, aur hum dono bina wajah hasi ja rahe the.",
      },
      {
        id: "m3",
        date: "2024-10-31",
        title: "Our Little Adventure",
        text: "Bhookh lagi thi, koi plan nahi tha, aur phir bhi sabse best din ban gaya.",
      },
      {
        id: "m4",
        date: "2025-02-14",
        title: "Officially Unofficially",
        text: "Aur tabhi se tum Mrs. Chopra ho gayi. (Sirf humare beech mein.)",
      },
    ],
    musicMode: "ambient",
    musicTitle: "Midnight Lap (ambient)",
    slideshowSeconds: 4,
  },

  doraemon: {
    alert: "ALERT! GOLU MOLU HAS ENTERED THE BUILDING.",
    nicknames: [
      "Malkin Ji",
      "Madam Ji",
      "Golu",
      "Molu",
      "Doraemon",
      "Mrs. Chopra",
      "Gadget Queen",
      "Pocket Ki Rani",
      "Meri Favourite Problem",
      "Golu Molu",
      "Bada Dramebaaz",
      "Sky Blue Princess",
    ],
    funnyMessages: [
      "Madam Ji, aapki attendance lag chuki hai.",
      "Golu Molu, aap officially meri favourite problem ho.",
      "Warning: Is ladki ki cuteness dangerous level par hai.",
      "Ek Doraemon mila tha, ab uske bina gadget bhi boring lagte hain.",
      "Breaking news: Mr. Chopra ne aaj phir Madam Ji ko bina wajah miss kiya. 📺",
      "Anywhere door mil jaata toh seedha tumhare paas aata, par abhi chai ke liye hi aana padega. ☕",
    ],
    affectionateMessages: [
      "Tum mere liye Doraemon ki pocket jaisi ho: jo bhi chahiye, tumhare paas milta hai. 💙",
      "Tumhari smile meri sabse rare gadget hai.",
      "Har din ek nayi wajah dhoondta hoon tumse pyaar karne ki, aur har baar mil jaati hai.",
      "Malkin Ji, jab tum bolti ho toh duniya ka shor bhi music lagta hai.",
      "Time machine chahiye? Nahi, bas tumhare saath wala aaj hi kaafi hai.",
      "Golu, tum bina batayi meri favourite ho gayi thi, aur ab tak wahi ho.",
      "Dil ka dabba bhi shayad tumhe yahi bol raha hoga: I love you. 💗",
    ],
    gifts: [
      {
        id: "g1",
        emoji: "🥟",
        name: "Infinite Dorayaki",
        message: "Ek dorayaki jo kabhi khatam nahi hota, bilkul mere pyaar ki tarah.",
      },
      {
        id: "g2",
        emoji: "🚁",
        name: "Bamboo Copter",
        message: "Bamboo copter se seedha tumhare paas udke aaunga... par pehle traffic check karna padega.",
      },
      {
        id: "g3",
        emoji: "🧠",
        name: "Brain Booster Pill",
        message: "Ye pill lo: ab tumhe mere bare mein sochna aur bhi easy hoga. 😌",
      },
      {
        id: "g4",
        emoji: "🚪",
        name: "Anywhere Door",
        message: "Anywhere door ka ek hi destination hai: tum. Chalo, koi bhi jagah choose karo.",
      },
      {
        id: "g5",
        emoji: "⏳",
        name: "Time Handkerchief",
        message: "Is rumaal se hum kisi bhi purane sweet moment mein wapas ja sakte hain.",
      },
      {
        id: "g6",
        emoji: "🔔",
        name: "Golden Bell",
        message: "Jab bhi lage ki main tumhe miss kar raha hoon, bas yeh bell bajana. Main aa jaunga.",
      },
    ],
  },

  letters: [
    {
      id: "miss-me",
      emoji: "💌",
      title: "Open when you miss me",
      body:
        "Malkin Ji,\n\nAgar tum yeh letter padh rahi ho, matlab tumhe meri yaad aa rahi hai. Aur sach kahun toh mujhe bhi utni hi aa rahi hai, shayad thodi zyada, kyunki main dramatic hoon. 😌\n\nJitna time tum mere saath nahi ho, woh ek lambi red-light jaisi lagti hai... jaldi se green ho jaaye.\n\nAankhein band karo, ek gehri saans lo, aur woh ek moment yaad karo jab tumne bina soche mujhe hasa diya tha. Woh moment main roz repeat karta hoon.\n\nBas itna yaad rakhna: main hamesha tumhare liye available hoon.\n\nBahut saara pyaar,",
      signature: "Tumhara Mr. Chopra ❤️",
    },
    {
      id: "angry",
      emoji: "😤",
      title: "Open when you're angry with me",
      body:
        "Madam Ji,\n\nAapne mujhe angry letter padhne ko bola hai, toh lo: main galat tha. (Shuruat mein thoda bahana tha, lekin ab sach bol raha hoon.)\n\nMujhe pata hai tum kitni strong ho, aur tumhara gussa bhi sahi hai jab tum sach mein hurt hoti ho. Main woh moment sudharna chahta hoon, tumhari baat sunna chahta hoon.\n\nAur agar abhi bhi gussa hai, toh ek kaam karo: 10 second ke liye bolo \"Chopra, tum bade bewakoof ho.\" Phir main sorry bolunga, aur tum thodi si smile karogi. Deal? 😌",
      signature: "Sorry wala, lekin pyaar wala Mr. Chopra",
    },
    {
      id: "sad",
      emoji: "🌧️",
      title: "Open when you're sad",
      body:
        "Golu,\n\nKabhi kabhi din bhaari lagta hai, aur bina wajah bhi dil bhaari ho jaata hai. Agar aaj aisa hi hai, toh pehle yeh jaan lo: tum akeli nahi ho.\n\nTumne kitni baar mujhe sambhala hai. Aaj meri baari hai.\n\nKoi bhi feeling ho, bolo. Rona ho toh ro lo, hasna ho toh hasna. Main sun raha hoon, aur bilkul bhi judge nahi karunga.\n\nAur ek chhota sa promise: kal ka din thoda aur bright hoga, jaise race mein last corner ke baad straight aata hai.",
      signature: "Tumhara personal bodyguard 🛡️",
    },
    {
      id: "sleep",
      emoji: "🌙",
      title: "Open when you can't sleep",
      body:
        "Molu,\n\nNeend nahi aa rahi? Koi baat nahi. Aaj hum ek virtual road trip pe chalte hain. Light off karo, phone thoda dur rakho.\n\nImagine karo ek raat, khuli road, chill music, aur tum meri side seat pe baithi ho, bina koi bakwaas ke. Bas chup-chap sheesha neeche karke taare dekh rahi ho.\n\nIs scene mein koi alarm nahi, koi deadline nahi. Sirf tum ho, aur main.\n\nGood night, Madam Ji. Sapno mein milte hain. 🌙",
      signature: "Lori-wala Mr. Chopra",
    },
    {
      id: "hug",
      emoji: "🤗",
      title: "Open when you need a hug",
      body:
        "Malkin Ji,\n\nYeh letter ek virtual hug hai, aur ek bahut lamba wala. Ready?\n\n*Ek, do, teen... (main tumhe kas ke pakad leta hoon)*\n\nAb thoda ro lo agar mann kar raha ho. Ya phir bas chup-chap saans lo. Main yahin hoon.\n\nAgar distance hai, toh is letter ko apni jacket ki pocket mein rakh lo. Jab bhi chahiye, khol lena.",
      signature: "Hug wala Chopra 🫂",
    },
    {
      id: "unloved",
      emoji: "💔",
      title: "Open when you feel unloved",
      body:
        "Parthiba,\n\nYeh feeling bahut heavy hoti hai, aur main chahta hoon tum jaan lo ki yeh sach nahi hai. Tum loved ho. Bahut zyada.\n\nMain tumhe roz bolna chahta hoon, lekin kabhi-kabhi shayad theek se bol nahi pata. Toh aaj likh raha hoon: tum special ho, tumhari baatein meri favourite hain, aur tumhari presence meri sabse important cheez hai.\n\nAgar kisi aur ne tumhe kabhi kam feel karwaya hai, toh woh unki problem hai, tumhari nahi. Tum ek whole universe ho, aur main us universe ka sabse loyal fan hoon.",
      signature: "Tumhara forever fan, Mr. Chopra ❤️",
    },
    {
      id: "smile",
      emoji: "😄",
      title: "Open when you want to smile",
      body:
        "Golu Molu,\n\nAb tum smile karo. Haan, abhi. Thodi si.\n\nAb ek aur baar. Ek Doraemon mila tha, ab uske bina gadget bhi boring lagte hain. Aur tum meri favourite problem ho.\n\nWarning: Is ladki ki cuteness dangerous level par hai. Smile karna mandatory hai.\n\nOkay, ab smile aayi? Bas, mission complete. 😎",
      signature: "Official Smile Inspector, Mr. Chopra",
    },
  ],

  arcade: {
    password: "MALKINJI",
    hints: [
      "Yeh naam main tumhe sabse zyada tab bulata hoon jab tum thodi dramatic hoti ho.",
      "Chhota naam, bada attitude. Kul 8 letters.",
      "Malkin + Ji, bina space ke.",
    ],
    mrQuiz: [
      {
        q: "Mr. Chopra ko sabse zyada kya pasand hai?",
        options: ["Long drives 🏎️", "Sirf sona", "Momos only", "Doraemon ka episode repeat"],
        answer: 0,
      },
      {
        q: "Mr. Chopra ka weakness kya hai?",
        options: ["Madam Ji ki smile", "Cold coffee", "Cute gadgets", "Sab upar wale"],
        answer: 0,
      },
      {
        q: "Jab Mr. Chopra gussa hote hain, woh kya karte hain?",
        options: [
          "Chup ho jaate hain",
          "Chai banate hain",
          "Gaana chalate hain",
          "Madam Ji ko dekhte hain aur ghabra jaate hain",
        ],
        answer: 3,
      },
      {
        q: "Mr. Chopra ka sabse bada dream?",
        options: ["Ek saath lamba road trip", "Mars", "Zero plans", "Ek saal ki chhutti"],
        answer: 0,
      },
    ],
    romanticQuiz: [
      {
        q: "Hamari pehli big date ka mood kya tha?",
        options: ["Nervous butterflies", "Full drama", "Sab kuch perfect", "Bhookh lagi thi"],
        answer: 0,
      },
      {
        q: "Hum mein se sabse zyada kaun bolti hai?",
        options: ["Madam Ji", "Mr. Chopra", "Dono together 😂", "Doraemon"],
        answer: 2,
      },
      {
        q: "Ghar mein kaun jeetta hai?",
        options: ["Mr. Chopra (ha ha)", "Madam Ji, obviously", "Kabhi koi nahi", "Pizza"],
        answer: 1,
      },
      {
        q: "Love ka best definition?",
        options: ["Tumhare saath chai", "Race ka last lap", "Bina wajah ki smile", "Sab sahi"],
        answer: 3,
      },
    ],
    hiddenMessages: [
      "Tum meri favourite problem ho. 💗",
      "Har din tumhe thoda aur pyaar karta hoon.",
      "Ghar wapas aane ka matlab hi tum ho.",
      "Tumhari hansi meri sabse badi chaav hai.",
      "Malkin Ji, you're my forever Pole Position.",
    ],
  },

  finale: {
    lines: [
      "Some people search for their favourite destination.",
      "Mine already has a name.",
      "PARTHIBA.",
      "From your biggest fan,\nYour personal Doraemon,\nYour Mr. Chopra. ❤️",
    ],
    signoff: "SEE YOU AT THE FINISH LINE, MRS. CHOPRA. 🏁",
  },
};
