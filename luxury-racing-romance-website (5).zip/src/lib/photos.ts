"use client";

import { listPhotos, putPhoto, putPhotos, type PhotoRecord } from "./idb";
import { uid } from "./utils";

const SEEDED_KEY = "mrs-chopra-universe:seeded";
let seeding: Promise<void> | null = null;

/** Adds the sample placeholder photos exactly once (safe to call from several pages). */
export function ensureSeeded(): Promise<void> {
  if (!seeding) {
    seeding = (async () => {
      if (localStorage.getItem(SEEDED_KEY) === "1") return;
      const existing = await listPhotos();
      if (existing.length === 0) await putPhotos(buildPlaceholderRecords());
      localStorage.setItem(SEEDED_KEY, "1");
    })().catch(() => {
      seeding = null;
    });
  }
  return seeding;
}

/* ─────────────────────────────────────────────────────────────
   Photo helpers: image optimisation for uploads and the sample
   placeholder photos that ship with the app. Placeholders are
   plain generated SVGs; delete them and upload real photos any time.
   ───────────────────────────────────────────────────────────── */

const MAX_EDGE = 1800;

/** Resize large photos to a sensible web size and re-encode as JPEG. */
export async function optimizeImage(file: File): Promise<Blob> {
  if (!file.type.startsWith("image/") || file.type === "image/svg+xml" || file.type === "image/gif") {
    return file;
  }
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.86));
    return blob ?? file;
  } catch {
    return file;
  }
}

/** Save uploaded files into a collection. Returns the created records. */
export async function uploadFiles(files: File[], collectionId: string): Promise<PhotoRecord[]> {
  const images = files.filter((f) => f.type.startsWith("image/"));
  const records: PhotoRecord[] = [];
  for (const file of images) {
    const blob = await optimizeImage(file);
    records.push({
      id: uid("ph"),
      collectionId,
      caption: file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").slice(0, 120),
      name: file.name,
      blob,
      createdAt: Date.now() + records.length,
    });
  }
  if (records.length) await putPhotos(records);
  return records;
}

export async function addPlaceholder(
  collectionId: string,
  caption: string,
  blob: Blob,
  order = 0,
): Promise<PhotoRecord> {
  const record: PhotoRecord = {
    id: uid("ph"),
    collectionId,
    caption,
    name: "placeholder.svg",
    blob,
    createdAt: Date.now() + order,
    placeholder: true,
  };
  await putPhoto(record);
  return record;
}

type Seed = { caption: string; a: string; b: string; w: number; h: number; collection: string };

const SEEDS: Seed[] = [
  { caption: "Our first coffee date. I was too nervous to drink mine ☕", a: "#e10600", b: "#2b0006", w: 1200, h: 1500, collection: "c-favourites" },
  { caption: "Lunch at 3 AM, zero regrets 🍜", a: "#e7a6b8", b: "#3a0a1c", w: 1500, h: 1100, collection: "c-everyday" },
  { caption: "Road trip, windows down, playlist on repeat 🏎️", a: "#2ea3ff", b: "#0c3b66", w: 1200, h: 1200, collection: "c-trips" },
  { caption: "Doraemon-level pose, pure chaos 💙", a: "#ffd23f", b: "#7a4a00", w: 1100, h: 1600, collection: "c-everyday" },
  { caption: "Golu Molu being dramatic again 😌", a: "#d4af37", b: "#2a1608", w: 1400, h: 1000, collection: "c-trips" },
  { caption: "Madam Ji, forever pole position 👑", a: "#ff4b3e", b: "#120000", w: 1200, h: 1400, collection: "c-favourites" },
];

function placeholderSvg(seed: Seed, index: number): string {
  const { w, h, a, b } = seed;
  const s = w / 380;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/>
    </linearGradient>
    <radialGradient id="r" cx="0.72" cy="0.22" r="0.7">
      <stop offset="0" stop-color="#fff" stop-opacity="0.38"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="url(#g)"/>
  <rect width="${w}" height="${h}" fill="url(#r)"/>
  <g transform="translate(${w / 2} ${h / 2}) scale(${s})" opacity="0.2">
    <path d="M0 -20 C -40 -70, -110 -10, -60 40 L 0 90 L 60 40 C 110 -10, 40 -70, 0 -20 Z" fill="#fff"/>
  </g>
  <text x="50%" y="${h * 0.9}" text-anchor="middle" font-family="Georgia, serif" font-size="${w * 0.034}" fill="#fff" opacity="0.92" letter-spacing="4">SAMPLE ${String(index + 1).padStart(2, "0")}</text>
  <text x="50%" y="${h * 0.93 + w * 0.04}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="${w * 0.025}" fill="#fff" opacity="0.7">Replace with our real photo</text>
</svg>`;
}

/** Create the sample placeholder photos (returns records, does not store them). */
export function buildPlaceholderRecords(): PhotoRecord[] {
  return SEEDS.map((seed, i) => ({
    id: uid("ph"),
    collectionId: seed.collection,
    caption: seed.caption,
    name: `sample-${i + 1}.svg`,
    blob: new Blob([placeholderSvg(seed, i)], { type: "image/svg+xml" }),
    createdAt: Date.now() + i,
    placeholder: true,
  }));
}
