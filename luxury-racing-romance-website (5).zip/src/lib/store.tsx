"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_SETTINGS, type Settings } from "./defaults";

const SETTINGS_KEY = "mrs-chopra-universe:settings";
const PROGRESS_KEY = "mrs-chopra-universe:progress";

export type Progress = {
  /** Experience routes the visitor has explored, e.g. "/race" */
  visited: string[];
  /** Completion flags, e.g. "game:catch", "letter:miss-me", "gift:g1", "mrs:crown" */
  done: string[];
};

const EMPTY_PROGRESS: Progress = { visited: [], done: [] };

type StoreValue = {
  settings: Settings;
  ready: boolean;
  setSection: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  resetSettings: () => void;
  replaceSettings: (next: Partial<Settings>) => void;
  progress: Progress;
  markVisited: (route: string) => void;
  markDone: (key: string) => void;
  resetProgress: () => void;
};

const StoreContext = createContext<StoreValue | null>(null);

/** Merge stored settings over defaults, one level deep, so new fields never break old saves. */
function mergeSettings(stored: Partial<Settings>): Settings {
  const out: Record<string, unknown> = { ...DEFAULT_SETTINGS };
  const defaults = DEFAULT_SETTINGS as unknown as Record<string, unknown>;
  const source = stored as unknown as Record<string, unknown>;
  for (const key of Object.keys(defaults)) {
    const value = source[key];
    if (value === undefined || value === null) continue;
    const def = defaults[key];
    if (typeof def === "object" && def !== null && !Array.isArray(def)) {
      out[key] = { ...(def as object), ...(value as object) };
    } else {
      out[key] = value;
    }
  }
  return out as unknown as Settings;
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettingsState] = useState<Settings>(DEFAULT_SETTINGS);
  const [progress, setProgress] = useState<Progress>(EMPTY_PROGRESS);
  const [ready, setReady] = useState(false);

  // Hydrate from localStorage after mount (server renders defaults, so no mismatch).
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) setSettingsState(mergeSettings(JSON.parse(raw)));
    } catch {
      /* corrupted storage: fall back to defaults */
    }
    try {
      const raw = localStorage.getItem(PROGRESS_KEY);
      if (raw) setProgress({ ...EMPTY_PROGRESS, ...JSON.parse(raw) });
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      /* storage full or blocked */
    }
  }, [settings, ready]);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    } catch {
      /* ignore */
    }
  }, [progress, ready]);

  // Theme switching: one attribute drives every CSS accent variable.
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
  }, [settings.theme]);

  const setSection = useCallback(<K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettingsState((prev) => ({ ...prev, [key]: value }));
  }, []);

  const resetSettings = useCallback(() => setSettingsState(DEFAULT_SETTINGS), []);

  const replaceSettings = useCallback((next: Partial<Settings>) => {
    setSettingsState(mergeSettings(next));
  }, []);

  const markVisited = useCallback((route: string) => {
    setProgress((p) => (p.visited.includes(route) ? p : { ...p, visited: [...p.visited, route] }));
  }, []);

  const markDone = useCallback((key: string) => {
    setProgress((p) => (p.done.includes(key) ? p : { ...p, done: [...p.done, key] }));
  }, []);

  const resetProgress = useCallback(() => setProgress(EMPTY_PROGRESS), []);

  const value = useMemo<StoreValue>(
    () => ({
      settings,
      ready,
      setSection,
      resetSettings,
      replaceSettings,
      progress,
      markVisited,
      markDone,
      resetProgress,
    }),
    [settings, ready, setSection, resetSettings, replaceSettings, progress, markVisited, markDone, resetProgress],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useSettings(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useSettings must be used inside <SettingsProvider>");
  return ctx;
}
