"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import type { Letter } from "@/lib/defaults";
import { paragraphs } from "@/lib/utils";
import { playChime } from "@/lib/audio";
import { FloatingParticles } from "@/components/floating-particles";

const ENVELOPE_TONES = ["#f6e7cb", "#f3dcc0", "#efd7b6", "#f7e9d2", "#eed3ae", "#f5e2c8", "#f1dcc4"];

function Envelope({ letter, index, opened, onOpen }: { letter: Letter; index: number; opened: boolean; onOpen: () => void }) {
  return (
    <motion.button
      type="button"
      onClick={onOpen}
      initial={{ opacity: 0, y: 40, rotate: index % 2 ? 2 : -2 }}
      whileInView={{ opacity: 1, y: 0, rotate: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.8, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -10, rotate: index % 2 ? -1 : 1 }}
      whileTap={{ scale: 0.97 }}
      className="group relative flex w-full flex-col items-center gap-5 text-center"
      aria-label={`Open letter: ${letter.title}`}
    >
      <div className="relative aspect-[4/3] w-full [perspective:800px]">
        {/* envelope body */}
        <div
          className="absolute inset-0 overflow-hidden rounded-xl shadow-[0_30px_60px_-20px_rgba(0,0,0,0.85)]"
          style={{ background: `linear-gradient(160deg, ${ENVELOPE_TONES[index % ENVELOPE_TONES.length]}, #d9b787)` }}
        >
          <div className="absolute inset-0 [clip-path:polygon(0_0,50%_52%,100%_0,100%_100%,0_100%)] bg-[#cfa873]/35" />
          <div className="absolute inset-x-0 bottom-0 h-1/2 [clip-path:polygon(0_100%,50%_0,100%_100%)] bg-[#e6c796]/60" />
        </div>
        {/* letter peeking out */}
        <motion.div
          className="paper absolute inset-x-[8%] top-[18%] bottom-[12%] rounded-md"
          animate={{ y: opened ? -4 : 0 }}
          transition={{ duration: 0.4 }}
        />
        {/* flap */}
        <motion.div
          className="absolute inset-x-0 top-0 h-1/2 origin-top [clip-path:polygon(0_0,100%_0,50%_100%)] rounded-t-xl bg-gradient-to-b from-[#fbeed6] to-[#ecd0a2] shadow-[0_6px_14px_rgba(0,0,0,0.25)]"
          animate={{ rotateX: opened ? 180 : 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformStyle: "preserve-3d" }}
        />
        {/* wax seal */}
        <motion.div
          className="absolute left-1/2 top-[48%] grid h-14 w-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#f08a9c,#8a0f2c_70%)] text-xl shadow-[0_6px_14px_rgba(0,0,0,0.4)]"
          animate={{ scale: opened ? 0 : 1, opacity: opened ? 0 : 1 }}
          transition={{ duration: 0.4 }}
        >
          {letter.emoji}
        </motion.div>
      </div>
      <div>
        <p className="font-display text-lg leading-snug text-white sm:text-xl">{letter.title}</p>
        <p className="mt-1 text-[10px] font-bold tracking-[0.25em] text-[#f6e7b0]/70 transition-colors group-hover:text-[#f6e7b0]">
          {opened ? "OPENED · READ AGAIN" : "TAP TO OPEN"}
        </p>
      </div>
    </motion.button>
  );
}

export default function LettersPage() {
  const { settings, progress, markDone } = useSettings();
  const letters = settings.letters;
  const [activeId, setActiveId] = useState<string | null>(null);
  const active = letters.find((l) => l.id === activeId) ?? null;
  const openedCount = letters.filter((l) => progress.done.includes(`letter:${l.id}`)).length;

  const openLetter = (letter: Letter) => {
    setActiveId(letter.id);
    markDone(`letter:${letter.id}`);
    playChime();
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-[radial-gradient(ellipse_at_top,#4a2233_0%,#1b0d18_45%,#0a0609_100%)] pb-32 pt-28 text-white">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[40rem] w-[40rem] -translate-x-1/2 -translate-y-1/3 rounded-full bg-[radial-gradient(circle,rgba(246,231,176,0.16),transparent_60%)]" />
      <FloatingParticles count={14} variant="petals" colors={["#f6e7b0", "#e7a6b8"]} />

      <div className="relative mx-auto max-w-6xl px-6 sm:px-10">
        <motion.header initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }} className="text-center">
          <p className="label !text-[#f6e7b0]">Website 05 · Letters for every mood</p>
          <h1 className="font-display mt-5 text-5xl leading-tight sm:text-7xl">
            Open <span className="italic text-[#f6e7b0]">when…</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-white/70 sm:text-lg">
            Seven sealed letters, one for every feeling. Choose the one your heart needs right now.
          </p>
          <div className="glass mx-auto mt-8 inline-flex items-center gap-3 rounded-full px-5 py-2.5 text-xs text-white/70">
            <span className="tabular font-bold text-white">
              {openedCount}/{letters.length}
            </span>
            letters opened
          </div>
        </motion.header>

        <div className="mt-20 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {letters.map((letter, i) => (
            <Envelope
              key={letter.id}
              letter={letter}
              index={i}
              opened={progress.done.includes(`letter:${letter.id}`)}
              onOpen={() => openLetter(letter)}
            />
          ))}
        </div>

        <p className="mt-24 text-center text-xs text-white/40">
          Every letter is editable in the Studio → Letters section. Bas likho, aur wo unki ho jaayengi.
        </p>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            key="letter-modal"
            className="fixed inset-0 z-[110] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActiveId(null)}
          >
            <motion.article
              role="dialog"
              aria-modal="true"
              aria-label={active.title}
              initial={{ y: 80, opacity: 0, rotateX: 12, scale: 0.96 }}
              animate={{ y: 0, opacity: 1, rotateX: 0, scale: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="paper relative max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-[28px] p-7 sm:p-12"
              style={{ transformPerspective: 1200 }}
            >
              <button
                type="button"
                onClick={() => setActiveId(null)}
                className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-[#3b2a20]/10 text-lg text-[#3b2a20] transition-colors hover:bg-[#3b2a20]/20"
                aria-label="Close letter"
              >
                ✕
              </button>
              <p className="text-[11px] font-bold tracking-[0.25em] text-[#8a5a2c]">
                {active.emoji} LETTER {String(letters.findIndex((l) => l.id === active.id) + 1).padStart(2, "0")} OF {letters.length}
              </p>
              <h2 className="font-display mt-4 text-3xl leading-tight sm:text-4xl">{active.title}</h2>
              <div className="mt-3 h-px w-20 bg-[#8a5a2c]/60" />
              <div className="mt-7 space-y-5">
                {paragraphs(active.body).map((para, i) => (
                  <motion.p
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 + i * 0.14 }}
                    className="font-display whitespace-pre-line text-lg leading-relaxed sm:text-xl"
                  >
                    {para}
                  </motion.p>
                ))}
              </div>
              <p className="font-display mt-10 text-right text-lg italic text-[#5a3d2a]">— {active.signature}</p>
            </motion.article>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
