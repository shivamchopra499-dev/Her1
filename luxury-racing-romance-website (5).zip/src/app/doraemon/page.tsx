"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import type { Gift } from "@/lib/defaults";
import { pick } from "@/lib/utils";
import { playChime } from "@/lib/audio";
import { FloatingParticles } from "@/components/floating-particles";

/* ───────────── Original Robo-buddy character (Doraemon-inspired, not copied) ───────────── */
function RoboBuddy({ className = "" }: { className?: string }) {
  return (
    <motion.svg
      viewBox="0 0 200 200"
      className={className}
      animate={{ y: [0, -8, 0] }}
      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      role="img"
      aria-label="Robo buddy character"
    >
      <circle cx="100" cy="100" r="86" fill="#2ea3ff" stroke="#0d6fc0" strokeWidth="4" />
      <ellipse cx="100" cy="118" rx="64" ry="56" fill="#ffffff" />
      <motion.g
        animate={{ scaleY: [1, 1, 0.1, 1, 1] }}
        transition={{ duration: 4, repeat: Infinity, times: [0, 0.8, 0.84, 0.88, 1] }}
        style={{ originY: "92px" }}
      >
        <ellipse cx="78" cy="92" rx="13" ry="17" fill="#111" />
        <ellipse cx="122" cy="92" rx="13" ry="17" fill="#111" />
        <circle cx="82" cy="86" r="4.5" fill="#fff" />
        <circle cx="126" cy="86" r="4.5" fill="#fff" />
      </motion.g>
      <circle cx="100" cy="117" r="9" fill="#ff3b30" />
      <path d="M100 126 L100 140 M80 140 Q100 158 120 140" stroke="#111" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M52 112 L22 106 M52 122 L20 124 M148 112 L178 106 M148 122 L180 124" stroke="#111" strokeWidth="2.5" strokeLinecap="round" />
      <rect x="58" y="164" width="84" height="13" rx="6.5" fill="#ff3b30" />
      <circle cx="100" cy="184" r="11" fill="#ffd23f" stroke="#b38600" strokeWidth="2.5" />
      <rect x="98" y="182" width="4" height="6" rx="2" fill="#b38600" />
    </motion.svg>
  );
}

/* ───────────── Clouds + stars backdrop ───────────── */
function Cloud({ top, scale, duration, delay }: { top: string; scale: number; duration: number; delay: number }) {
  return (
    <motion.svg
      viewBox="0 0 160 70"
      className="pointer-events-none absolute w-44 fill-white/90 drop-shadow-[0_8px_20px_rgba(0,80,140,0.25)]"
      style={{ top, scale }}
      initial={{ x: "-30vw" }}
      animate={{ x: ["-30vw", "120vw"] }}
      transition={{ duration, repeat: Infinity, ease: "linear", delay }}
      aria-hidden
    >
      <circle cx="45" cy="42" r="24" />
      <circle cx="82" cy="30" r="30" />
      <circle cx="120" cy="44" r="20" />
      <rect x="20" y="42" width="120" height="24" rx="12" />
    </motion.svg>
  );
}

/* ───────────── Gift box ───────────── */
function GiftBox({ gifts }: { gifts: Gift[] }) {
  const { markDone } = useSettings();
  const [open, setOpen] = useState(false);
  const [gift, setGift] = useState<Gift | null>(null);

  const openBox = () => {
    if (gifts.length === 0) return;
    const g = pick(gifts);
    setGift(g);
    setOpen(true);
    markDone(`gift:${g.id}`);
    playChime();
  };

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="relative h-44 w-44">
        <AnimatePresence>
          {open && gift && (
            <motion.div
              key={gift.id}
              initial={{ y: 40, scale: 0.3, opacity: 0 }}
              animate={{ y: -58, scale: 1, opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ type: "spring", stiffness: 180, damping: 12 }}
              className="absolute left-1/2 top-2 -translate-x-1/2 text-6xl drop-shadow-[0_8px_16px_rgba(0,0,0,0.25)]"
            >
              {gift.emoji}
            </motion.div>
          )}
        </AnimatePresence>
        <motion.div
          animate={{ y: open ? -36 : 0, rotate: open ? -16 : 0 }}
          transition={{ type: "spring", stiffness: 160, damping: 14 }}
          className="absolute inset-x-0 top-[52px] h-9 rounded-xl border-2 border-[#a9d8ff] bg-gradient-to-b from-white to-[#d5ecff] shadow-md"
        >
          <span className="absolute inset-y-0 left-1/2 w-5 -translate-x-1/2 bg-[#ffd23f]" />
        </motion.div>
        <motion.button
          type="button"
          onClick={openBox}
          disabled={open}
          whileHover={{ scale: open ? 1 : 1.04 }}
          whileTap={{ scale: 0.96 }}
          aria-label="Open the Doraemon-style gift box"
          className="absolute bottom-0 left-1/2 h-28 w-36 -translate-x-1/2 rounded-2xl border-2 border-[#a9d8ff] bg-gradient-to-b from-white to-[#cce8ff] shadow-[0_18px_40px_-10px_rgba(0,70,130,0.6)] disabled:cursor-default"
        >
          <span className="absolute inset-y-0 left-1/2 w-6 -translate-x-1/2 bg-[#ffd23f]" />
          <span className="absolute inset-x-0 top-1/2 h-4 -translate-y-1/2 bg-[#ff6b8a]/0" />
          {!open && <span className="absolute inset-x-0 bottom-3 text-[10px] font-bold tracking-[0.25em] text-[#0d6fc0]">TAP ME</span>}
        </motion.button>
      </div>

      {!open ? (
        <button type="button" onClick={openBox} className="btn btn-accent">
          Open the gift box 🎁
        </button>
      ) : (
        <button
          type="button"
          onClick={() => {
            setOpen(false);
            setGift(null);
          }}
          className="btn btn-ghost"
        >
          Close &amp; shake again
        </button>
      )}

      <AnimatePresence mode="wait">
        {gift && (
          <motion.div
            key={gift.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="max-w-sm rounded-2xl bg-white/90 p-5 text-[#0a3d66] shadow-xl"
          >
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0d6fc0]">New gadget unlocked</p>
            <p className="mt-1 text-lg font-extrabold">{gift.name}</p>
            <p className="mt-2 text-sm leading-relaxed">{gift.message}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ───────────── Anywhere door ───────────── */
const DESTINATIONS = [
  "Madam Ji ki favourite chai wali jagah ☕",
  "Ek hilltop jahan sirf hum dono ho 🏔️",
  "Doraemon ki pocket ke andar, sitaron ke beech 🌌",
  "Mr. Chopra ka dil, jahan tum hamesha ho 💙",
  "Ek lamba road trip, bina destination ke 🏎️",
];

function AnywhereDoor({ messages }: { messages: string[] }) {
  const [opened, setOpened] = useState(false);
  const [message, setMessage] = useState("");
  const [destination, setDestination] = useState("");

  const toggle = () => {
    if (!opened) {
      setMessage(pick(messages.length ? messages : ["Tum meri favourite ho. 💙"]));
      setDestination(pick(DESTINATIONS));
      playChime();
    }
    setOpened((v) => !v);
  };

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="relative h-72 w-56 [perspective:1000px]">
        <div className="absolute inset-0 flex flex-col justify-end overflow-hidden rounded-t-[120px] rounded-b-2xl border-[10px] border-white bg-gradient-to-b from-[#e8f6ff] to-[#9ed8ff] p-5 shadow-[0_25px_60px_-15px_rgba(0,60,120,0.6)]">
          <p className="font-display text-base italic text-[#0a3d66]">{destination || "Where do you want to go?"}</p>
          <p className="mt-3 text-sm font-semibold leading-relaxed text-[#0a3d66]/90">
            {opened ? message : "Tap the door to open a surprise destination."}
          </p>
        </div>
        <motion.button
          type="button"
          onClick={toggle}
          aria-label={opened ? "Close the anywhere door" : "Open the anywhere door"}
          animate={{ rotateY: opened ? -104 : 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformOrigin: "left center", transformStyle: "preserve-3d" }}
          className="absolute inset-0 flex items-end justify-end rounded-t-[120px] rounded-b-2xl border-[10px] border-white bg-gradient-to-b from-[#2ea3ff] to-[#0d6fc0] p-6 shadow-[inset_0_0_40px_rgba(255,255,255,0.25)]"
        >
          <span className="absolute left-1/2 top-8 -translate-x-1/2 text-[10px] font-black tracking-[0.3em] text-white/80">ANYWHERE</span>
          <span className="absolute left-1/2 top-[30%] h-16 w-24 -translate-x-1/2 rounded-md border-4 border-white/70" />
          <span className="h-4 w-4 rounded-full bg-[#ffd23f] shadow-[0_0_14px_#ffd23f]" />
        </motion.button>
      </div>
      <button type="button" onClick={toggle} className="btn btn-accent">
        {opened ? "Close the door" : "Open the anywhere door 🚪"}
      </button>
    </div>
  );
}

/* ───────────── Nickname roulette ───────────── */
function NicknameRoulette({ names }: { names: string[] }) {
  const [current, setCurrent] = useState<string>(names[0] ?? "Malkin Ji");
  const [spinning, setSpinning] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => () => {
    if (timer.current) window.clearInterval(timer.current);
  }, []);

  const spin = () => {
    if (spinning || names.length === 0) return;
    setSpinning(true);
    let ticks = 0;
    timer.current = window.setInterval(() => {
      ticks += 1;
      setCurrent(pick(names));
      if (ticks >= 14) {
        if (timer.current) window.clearInterval(timer.current);
        timer.current = null;
        setSpinning(false);
        playChime();
      }
    }, 85);
  };

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="flex min-h-[7rem] w-full items-center justify-center rounded-3xl border-2 border-dashed border-white/70 bg-white/15 px-4 backdrop-blur">
        <AnimatePresence mode="wait">
          <motion.p
            key={current + (spinning ? "s" : "d")}
            initial={{ opacity: 0, scale: 0.8, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.15 }}
            className="font-f1 text-2xl font-black text-white [text-shadow:0_3px_0_#0d6fc0] sm:text-3xl"
          >
            {current}
          </motion.p>
        </AnimatePresence>
      </div>
      <button type="button" onClick={spin} disabled={spinning} className="btn btn-gold">
        {spinning ? "Rolling…" : "Generate a nickname 🎲"}
      </button>
      <p className="text-xs text-white/80">Use it like: &ldquo;Oye {current}, chai pilaogi?&rdquo;</p>
    </div>
  );
}

/* ───────────── Page ───────────── */
export default function DoraemonPage() {
  const { settings, progress, markDone } = useSettings();
  const d = settings.doraemon;
  const [bubble, setBubble] = useState("Namaste Malkin Ji! Aaj ka mission: aapko smile dilana. 💙");
  const [bubbleKey, setBubbleKey] = useState(0);

  const surprise = () => {
    const pool = [...d.affectionateMessages, ...d.funnyMessages];
    if (pool.length === 0) return;
    setBubble(pick(pool));
    setBubbleKey((k) => k + 1);
    markDone("doraemon:surprise");
    playChime();
  };

  const collected = d.gifts.filter((g) => progress.done.includes(`gift:${g.id}`));

  return (
    <main className="sky-bg relative min-h-screen overflow-hidden pb-32 pt-24 text-white">
      <div className="pointer-events-none absolute inset-0">
        <Cloud top="12%" scale={1} duration={46} delay={0} />
        <Cloud top="34%" scale={0.7} duration={60} delay={-20} />
        <Cloud top="62%" scale={1.25} duration={52} delay={-8} />
        <Cloud top="84%" scale={0.8} duration={70} delay={-40} />
      </div>
      <FloatingParticles count={16} variant="stars" colors={["#ffffff", "#fff3a0", "#d8f1ff"]} />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-10">
        {/* Alert */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-auto flex w-fit max-w-full items-center gap-3 rounded-full border-2 border-white bg-[#0d6fc0]/80 px-5 py-3 shadow-[0_10px_40px_-10px_rgba(0,50,100,0.6)] backdrop-blur"
        >
          <motion.span
            className="h-3 w-3 shrink-0 rounded-full bg-[#ff3b30]"
            animate={{ opacity: [1, 0.2, 1], boxShadow: ["0 0 0px #ff3b30", "0 0 18px #ff3b30", "0 0 0px #ff3b30"] }}
            transition={{ duration: 1, repeat: Infinity }}
          />
          <p className="text-center text-xs font-black tracking-[0.12em] sm:text-sm">{d.alert}</p>
        </motion.div>

        {/* Hero */}
        <section className="mt-12 grid items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
          <div className="flex flex-col items-center text-center lg:items-start lg:text-left">
            <RoboBuddy className="h-56 w-56 drop-shadow-[0_20px_40px_rgba(0,60,120,0.45)] sm:h-72 sm:w-72" />
          </div>
          <div className="flex flex-col gap-6">
            <p className="font-display text-4xl leading-tight [text-shadow:0_4px_20px_rgba(0,60,120,0.35)] sm:text-6xl">
              Doraemon&apos;s <span className="italic">Secret</span> World
            </p>
            <div className="relative rounded-[28px] bg-white p-6 text-[#0a3d66] shadow-[0_25px_60px_-15px_rgba(0,60,120,0.5)] sm:p-8">
              <span className="absolute -left-2 top-10 h-4 w-4 rotate-45 bg-white" aria-hidden />
              <AnimatePresence mode="wait">
                <motion.p
                  key={bubbleKey}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="text-lg font-bold leading-relaxed sm:text-xl"
                >
                  {bubble}
                </motion.p>
              </AnimatePresence>
            </div>
            <div className="flex flex-wrap gap-3">
              <button type="button" onClick={surprise} className="btn btn-gold">
                Surprise me 💬
              </button>
              <span className="glass self-center rounded-full px-4 py-2 text-xs font-semibold text-white">
                Gadgets collected: {collected.length}/{d.gifts.length}
              </span>
            </div>
          </div>
        </section>

        {/* Gadget lab */}
        <section className="mt-24 grid gap-6 md:grid-cols-3">
          <div className="rounded-[32px] border-2 border-white/80 bg-white/20 p-7 text-center backdrop-blur-md">
            <p className="label !text-white">Gadget 01</p>
            <h2 className="font-display mt-2 mb-6 text-2xl">Mystery Gift Box</h2>
            <GiftBox gifts={d.gifts} />
          </div>
          <div className="rounded-[32px] border-2 border-white/80 bg-white/20 p-7 text-center backdrop-blur-md">
            <p className="label !text-white">Gadget 02</p>
            <h2 className="font-display mt-2 mb-6 text-2xl">Anywhere Door</h2>
            <AnywhereDoor messages={d.affectionateMessages} />
          </div>
          <div className="rounded-[32px] border-2 border-white/80 bg-white/20 p-7 text-center backdrop-blur-md">
            <p className="label !text-white">Gadget 03</p>
            <h2 className="font-display mt-2 mb-6 text-2xl">Nickname Roulette</h2>
            <NicknameRoulette names={d.nicknames} />
          </div>
        </section>

        {/* Funny messages */}
        <section className="mt-24">
          <p className="label !text-white">Official warnings from the building</p>
          <h2 className="font-display mt-3 text-3xl sm:text-5xl">Funny, but true.</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {d.funnyMessages.map((m, i) => (
              <motion.div
                key={m + i}
                initial={{ opacity: 0, y: 20, rotate: i % 2 ? 1.5 : -1.5 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="rounded-3xl bg-white/90 p-6 text-[#0a3d66] shadow-[0_18px_40px_-16px_rgba(0,60,120,0.5)]"
              >
                <p className="text-[10px] font-black tracking-[0.25em] text-[#0d6fc0]">MESSAGE #{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-2 text-base font-bold leading-relaxed sm:text-lg">{m}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Gift collection */}
        <section className="mt-24">
          <p className="label !text-white">Digital gift collection</p>
          <h2 className="font-display mt-3 text-3xl sm:text-5xl">
            Your little gadgets, <span className="italic">{collected.length}/{d.gifts.length}</span>
          </h2>
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-3">
            {d.gifts.map((g) => {
              const unlocked = progress.done.includes(`gift:${g.id}`);
              return (
                <motion.div
                  key={g.id}
                  whileHover={{ y: -4 }}
                  className={`flex flex-col items-center gap-3 rounded-3xl border-2 p-6 text-center ${
                    unlocked ? "border-white bg-white/90 text-[#0a3d66]" : "border-dashed border-white/60 bg-white/10 text-white/80"
                  }`}
                >
                  <span className={`text-5xl ${unlocked ? "" : "grayscale opacity-60"}`}>{unlocked ? g.emoji : "❔"}</span>
                  <p className="font-extrabold">{unlocked ? g.name : "Locked gadget"}</p>
                  <p className="text-xs leading-relaxed opacity-80">{unlocked ? g.message : "Gift box se milega!"}</p>
                </motion.div>
              );
            })}
          </div>
        </section>

        <p className="mt-20 text-center text-xs font-semibold text-white/80">
          Sky ki tarah open, golu molu ki tarah cute. 💙
        </p>
      </div>
    </main>
  );
}
