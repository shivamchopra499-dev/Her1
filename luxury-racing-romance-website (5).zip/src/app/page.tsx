"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { EXPERIENCES } from "@/lib/defaults";
import { useSettings } from "@/lib/store";
import { FloatingParticles } from "@/components/floating-particles";
import { FadeLink } from "@/components/fade-link";
import { ExperienceCards } from "@/components/home/experience-cards";

export default function HomePage() {
  const { progress } = useSettings();
  const explored = EXPERIENCES.filter((e) => progress.visited.includes(e.href)).length;
  const allExplored = explored === EXPERIENCES.length;

  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Cinematic backdrop: racing red, romance rose, doraemon sky glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 -top-40 h-[32rem] w-[32rem] rounded-full bg-[radial-gradient(circle,rgba(225,6,0,.35),transparent_65%)] blur-2xl" />
        <div className="absolute -right-40 top-[30%] h-[30rem] w-[30rem] rounded-full bg-[radial-gradient(circle,rgba(231,166,184,.22),transparent_65%)] blur-2xl" />
        <div className="absolute bottom-[-10rem] left-1/3 h-[28rem] w-[28rem] rounded-full bg-[radial-gradient(circle,rgba(46,163,255,.2),transparent_65%)] blur-2xl" />
      </div>

      {/* Hero */}
      <section className="relative flex min-h-[100svh] flex-col justify-center px-6 pb-16 pt-28 sm:px-10 lg:px-20">
        <FloatingParticles count={22} variant="hearts" colors={["#ff7aa2", "#e10600", "#f6e7b0"]} />
        <div className="relative mx-auto w-full max-w-7xl">
          <motion.p
            initial={{ opacity: 0, letterSpacing: "0.1em" }}
            animate={{ opacity: 1, letterSpacing: "0.32em" }}
            transition={{ duration: 1.2 }}
            className="label !text-[color:var(--accent)]"
          >
            Official Universe · Est. Officially Unofficially
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="font-f1 mt-6 text-[2.6rem] font-black leading-[0.95] tracking-tight sm:text-7xl lg:text-[7.5rem]"
          >
            MRS<span className="text-[color:var(--accent)]">.</span> CHOPRA
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="font-display mt-3 text-2xl italic text-white/85 sm:text-4xl lg:text-5xl"
          >
            <span className="gold-text not-italic">The Love Universe</span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.7 }}
            className="racing-line mt-10 w-full max-w-xl"
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.9 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg"
          >
            Ek universe, sirf <span className="font-semibold text-white">Parthiba</span> ke liye.
            Six worlds, ek destination: <span className="text-white">aap.</span> Har door ke peeche ek surprise hai, Malkin Ji.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 1.1 }}
            className="mt-9 flex flex-wrap gap-3"
          >
            <Link href="/race" className="btn btn-accent">
              Start the Race 🏎️
            </Link>
            <Link href="/mrs-chopra" className="btn btn-ghost">
              Madam Ji 👑
            </Link>
            <Link href="/studio" className="btn btn-ghost">
              Personalise ✏️
            </Link>
          </motion.div>

          {/* Exploration meter */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.4 }}
            className="glass mt-12 flex max-w-md items-center gap-4 rounded-2xl p-4"
          >
            <div className="flex-1">
              <div className="label mb-2 flex justify-between">
                <span>Worlds explored</span>
                <span className="tabular text-white">
                  {explored}/{EXPERIENCES.length}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-[color:var(--accent)] to-[color:var(--accent-2)]"
                  initial={{ width: 0 }}
                  animate={{ width: `${(explored / EXPERIENCES.length) * 100}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Universe grid */}
      <section className="relative px-6 pb-24 sm:px-10 lg:px-20">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="label">Choose your world</p>
              <h2 className="font-display mt-2 text-3xl sm:text-5xl">
                Six worlds. <span className="italic text-white/70">Zero boring rooms.</span>
              </h2>
            </div>
            <p className="max-w-sm text-sm text-white/55">
              Every world is its own little theme. Everything here is editable from the Studio, saved in this browser.
            </p>
          </div>

          <ExperienceCards />

          {/* Hidden finale door: revealed only after exploring every world */}
          <div className="mt-28 flex flex-col items-center text-center">
            {allExplored ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                className="flex flex-col items-center gap-5"
              >
                <p className="label !text-[color:var(--accent-2)]">A hidden door has opened</p>
                <FadeLink
                  href="/finale"
                  className="btn btn-gold !px-8 !py-4 !text-sm animate-pulse"
                >
                  ONE LAST THING, MADAM JI... 💖
                </FadeLink>
              </motion.div>
            ) : (
              <div className="glass flex items-center gap-3 rounded-full px-5 py-3 text-xs text-white/55">
                <span aria-hidden>🔒</span>
                Explore all six worlds to unlock something hidden here.
              </div>
            )}
          </div>

          <footer className="mt-20 flex flex-col items-center gap-2 border-t border-white/10 pt-8 text-center text-xs text-white/45">
            <p>Made with ❤️ by Mr. Chopra, exclusively for Malkin Ji.</p>
            <p>Browser-saved memories · Shared reactions &amp; notes live on the server.</p>
          </footer>
        </div>
      </section>
    </main>
  );
}
