import { db } from "@/db";
import { photoReactions } from "@/db/schema";
import { inArray, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const ID_PATTERN = /^[a-zA-Z0-9_-]{1,64}$/;

/** GET /api/reactions?ids=a,b,c → { counts: { a: 3, b: 0 } } */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const ids = (url.searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((id) => ID_PATTERN.test(id))
    .slice(0, 200);

  if (ids.length === 0) return Response.json({ counts: {} });

  try {
    const rows = await db.select().from(photoReactions).where(inArray(photoReactions.photoId, ids));
    const counts: Record<string, number> = {};
    for (const row of rows) counts[row.photoId] = row.hearts;
    return Response.json({ counts });
  } catch {
    return Response.json({ error: "Reactions are unavailable right now." }, { status: 503 });
  }
}

/** POST /api/reactions  { photoId } → increments the heart count for that photo. */
export async function POST(request: Request) {
  let body: { photoId?: unknown };
  try {
    body = (await request.json()) as { photoId?: unknown };
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const photoId = typeof body.photoId === "string" ? body.photoId : "";
  if (!ID_PATTERN.test(photoId)) {
    return Response.json({ error: "Invalid photo id." }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(photoReactions)
      .values({ photoId, hearts: 1 })
      .onConflictDoUpdate({
        target: photoReactions.photoId,
        set: { hearts: sql`${photoReactions.hearts} + 1` },
      })
      .returning();
    return Response.json({ photoId, hearts: row.hearts });
  } catch {
    return Response.json({ error: "Could not save the heart." }, { status: 503 });
  }
}
