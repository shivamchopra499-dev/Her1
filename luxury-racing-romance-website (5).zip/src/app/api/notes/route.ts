import { db } from "@/db";
import { loveNotes } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

const MAX_LENGTH = 500;

/** GET /api/notes → latest replies from Mrs. Chopra (newest first). */
export async function GET() {
  try {
    const rows = await db.select().from(loveNotes).orderBy(desc(loveNotes.createdAt)).limit(50);
    return Response.json({
      notes: rows.map((r) => ({ id: r.id, message: r.message, createdAt: r.createdAt.toISOString() })),
    });
  } catch {
    return Response.json({ error: "Inbox is unavailable right now." }, { status: 503 });
  }
}

/** POST /api/notes  { message } → stores a reply for Mr. Chopra. */
export async function POST(request: Request) {
  let body: { message?: unknown };
  try {
    body = (await request.json()) as { message?: unknown };
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (message.length === 0 || message.length > MAX_LENGTH) {
    return Response.json({ error: `Message must be 1–${MAX_LENGTH} characters.` }, { status: 400 });
  }

  try {
    const [row] = await db.insert(loveNotes).values({ message }).returning();
    return Response.json({ id: row.id, createdAt: row.createdAt.toISOString() }, { status: 201 });
  } catch {
    return Response.json({ error: "Could not send the note." }, { status: 503 });
  }
}
