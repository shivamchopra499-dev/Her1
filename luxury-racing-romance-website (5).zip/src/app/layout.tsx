import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SettingsProvider } from "@/lib/store";
import { SiteNav } from "@/components/site-nav";

export const metadata: Metadata = {
  title: "Mrs. Chopra — The Love Universe",
  description: "A premium personal universe made by Mr. Chopra for Parthiba, Madam Ji.",
};

export const viewport: Viewport = {
  themeColor: "#070708",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" data-theme="racing" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400;1,600&family=Montserrat:wght@300;400;500;600;800;900&family=Orbitron:wght@500;700;900&family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased">
        <SettingsProvider>
          <SiteNav />
          {children}
        </SettingsProvider>
      </body>
    </html>
  );
}
