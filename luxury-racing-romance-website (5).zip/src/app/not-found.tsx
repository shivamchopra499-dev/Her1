import Link from "next/link";

export default function NotFound() {
  return (
    <main className="relative grid min-h-[100svh] place-items-center overflow-hidden bg-[#070708] px-6 text-center">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(225,6,0,0.18),transparent_60%)]" />
      <div className="relative flex max-w-lg flex-col items-center gap-6">
        <p className="label !text-[color:var(--accent)]">Wrong turn, Madam Ji</p>
        <h1 className="font-f1 text-6xl font-black">404</h1>
        <p className="font-display text-2xl italic text-white/80">
          Ye road universe mein nahi hai. Par aap jahan bhi jaogi, main wahi milunga. 💗
        </p>
        <Link href="/" className="btn btn-accent">
          Back to the Love Universe
        </Link>
      </div>
    </main>
  );
}
