import type { Metadata } from "next";
import { MrsExperience } from "@/components/mrs/mrs-experience";

export const metadata: Metadata = {
  title: "Officially Unofficially, Mrs. Chopra",
};

export default function MrsChopraPage() {
  return <MrsExperience />;
}
