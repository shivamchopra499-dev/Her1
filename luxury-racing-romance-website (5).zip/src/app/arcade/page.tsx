"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useAnimationControls } from "framer-motion";
import { useSettings } from "@/lib/store";
import type { QuizQuestion } from "@/lib/defaults";
import { normalizeSecret, pick } from "@/lib/utils";
import { playChime } from "@/lib/audio";
import { FadeLink } from "@/components/fade-link";
import { FloatingParticles } from "@/components/floating-particles";

type GameId = "mrquiz" | "catch" | "password" | "romantic" | "hidden";

const GAMES: { id: GameId; name: string; icon: string; blurb: string }[] = [
  { id: "mrquiz", name: "How well do you know Mr. Chopra?", icon: "🧠", blurb: "Quiz about the man himself." },
  { id: "catch", name: "Catch the hearts", icon: "💗", blurb: "Catch 15 hearts. Avoid the broken ones." },
  { id: "password", name: "Unlock the secret password", icon: "🔐", blurb: "Hints are waiting for you." },
  { id: "romantic", name: "Romantic quiz", icon: "💘", blurb: "How well do we know each other?" },
  { id: "hidden", name: "Find the hidden love messages", icon: "🔍", blurb: "Tap the tiles. Find every note." },
];

/* ───────────── Quiz (used by two games) ───────────── */
function Quiz({
  questions,
  results,
  onComplete,
}: {
  questions: QuizQuestion[];
  results: [string, string, string];
  onComplete: () => void;
}) {
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  if (questions.length === 0) {
    return <p className="text-white/60">No questions yet. Add some in the Studio → Arcade.</p>;
  }

  const q = questions[index];

  const choose = (i: number) => {
    if (picked !== null) return;
    setPicked(i);
    if (i === q.answer) {
      setScore((s) => s + 1);
      playChime();
    }
  };

  const next = () => {
    if (index + 1 >= questions.length) {
      setFinished(true);
      onComplete();
    } else {
      setIndex((v) => v + 1);
      setPicked(null);
    }
  };

  const restart = () => {
    setIndex(0);
    setPicked(null);
    setScore(0);
    setFinished(false);
  };

  if (finished) {
    const ratio = score / questions.length;
    const message = ratio === 1 ? results[0] : ratio >= 0.5 ? results[1] : results[2];
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
        <p className="font-f1 text-5xl font-black text-[#ff3dbb] [text-shadow:0_0_20px_#ff3dbb]">
          {score}/{questions.length}
        </p>
        <p className="mx-auto mt-5 max-w-lg text-lg leading-relaxed text-white/85">{message}</p>
        <button type="button" onClick={restart} className="btn btn-ghost mt-8">
          Play again
        </button>
      </motion.div>
    );
  }

  return (
    <div>
      <div className="mb-5 flex items-center justify-between text-xs text-white/55">
        <span className="tabular">
          Question {index + 1}/{questions.length}
        </span>
        <span className="tabular">Score {score}</span>
      </div>
      <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
        <div className="h-full bg-gradient-to-r from-[#ff3dbb] to-[#5ff0ff] transition-all" style={{ width: `${((index + (picked !== null ? 1 : 0)) / questions.length) * 100}%` }} />
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={index} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.3 }}>
          <p className="font-display mt-8 text-2xl leading-snug sm:text-3xl">{q.q}</p>
          <div className="mt-7 grid gap-3 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isCorrect = i === q.answer;
              const isPicked = picked === i;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => choose(i)}
                  disabled={picked !== null}
                  className={`rounded-2xl border px-5 py-4 text-left text-sm font-semibold transition-all sm:text-base ${
                    picked === null
                      ? "border-white/15 bg-white/5 hover:border-[#5ff0ff]/60 hover:bg-white/10"
                      : isCorrect
                        ? "border-[#5ff0ff] bg-[#5ff0ff]/15 text-white"
                        : isPicked
                          ? "border-[#ff3b30] bg-[#ff3b30]/15 text-white"
                          : "border-white/10 bg-white/[0.02] text-white/40"
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          {picked !== null && (
            <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
              <p className={`text-sm font-bold ${picked === q.answer ? "text-[#5ff0ff]" : "text-[#ff8a80]"}`}>
                {picked === q.answer ? "Correct! Sahi pakde ho. 💖" : `Oops! Sahi jawab: ${q.options[q.answer]}`}
              </p>
              <button type="button" onClick={next} className="btn btn-accent !min-h-10 !py-2">
                {index + 1 >= questions.length ? "See result" : "Next →"}
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/* ───────────── Catch the hearts ───────────── */
const TARGET = 15;
const SECONDS = 25;
type Falling = { id: number; x: number; y: number; kind: "heart" | "bomb"; speed: number };

function CatchHearts({ onWin }: { onWin: () => void }) {
  const [phase, setPhase] = useState<"idle" | "playing" | "won" | "lost">("idle");
  const [items, setItems] = useState<Falling[]>([]);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(SECONDS);
  const nextId = useRef(1);

  useEffect(() => {
    if (phase !== "playing") return;
    const spawn = window.setInterval(() => {
      setItems((prev) => {
        const moved = prev.map((it) => ({ ...it, y: it.y + it.speed })).filter((it) => it.y < 100);
        if (Math.random() < 0.3) {
          moved.push({
            id: nextId.current++,
            x: 6 + Math.random() * 88,
            y: -8,
            kind: Math.random() < 0.22 ? "bomb" : "heart",
            speed: 0.9 + Math.random() * 1.1,
          });
        }
        return moved;
      });
    }, 60);
    const clock = window.setInterval(() => setTime((s) => s - 1), 1000);
    return () => {
      window.clearInterval(spawn);
      window.clearInterval(clock);
    };
  }, [phase]);

  useEffect(() => {
    if (phase === "playing" && time <= 0) {
      setPhase("lost");
      setItems([]);
    }
  }, [time, phase]);

  useEffect(() => {
    if (phase === "playing" && score >= TARGET) {
      setPhase("won");
      setItems([]);
      onWin();
      playChime();
    }
  }, [score, phase, onWin]);

  const start = () => {
    setScore(0);
    setTime(SECONDS);
    setItems([]);
    setPhase("playing");
  };

  const catchItem = (it: Falling) => {
    setItems((prev) => prev.filter((x) => x.id !== it.id));
    if (it.kind === "heart") setScore((s) => s + 1);
    else setScore((s) => Math.max(0, s - 2));
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between text-xs font-bold tracking-[0.2em] text-white/70">
        <span className="tabular">SCORE {score}/{TARGET}</span>
        <span className="tabular">TIME {Math.max(0, time)}s</span>
      </div>
      <div className="relative h-80 w-full touch-none overflow-hidden rounded-3xl border border-[#ff3dbb]/40 bg-[#07020c] arcade-grid sm:h-96">
        {items.map((it) => (
          <button
            key={it.id}
            type="button"
            onPointerDown={() => phase === "playing" && catchItem(it)}
            aria-label={it.kind === "heart" ? "Catch heart" : "Avoid broken heart"}
            className="absolute -translate-x-1/2 select-none text-3xl transition-transform active:scale-75 sm:text-4xl"
            style={{ left: `${it.x}%`, top: `${it.y}%` }}
          >
            {it.kind === "heart" ? "💗" : "💔"}
          </button>
        ))}
        {phase !== "playing" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black/60 p-6 text-center backdrop-blur-sm">
            {phase === "idle" && <p className="font-display text-xl italic">Catch 15 hearts in 25 seconds. Broken hearts −2.</p>}
            {phase === "won" && <p className="font-display text-2xl italic">Cleared! Itne saare hearts, sab tumhare liye. 💖</p>}
            {phase === "lost" && <p className="font-display text-xl italic">Time up! Ek aur try, Madam Ji? 💔</p>}
            <button type="button" onClick={start} className="btn btn-accent">
              {phase === "won" ? "Play again" : phase === "lost" ? "Try again" : "Start catching"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ───────────── Password ───────────── */
function PasswordGame({ password, hints, onWin }: { password: string; hints: string[]; onWin: () => void }) {
  const [revealed, setRevealed] = useState(1);
  const [value, setValue] = useState("");
  const [error, setError] = useState("");
  const controls = useAnimationControls();
  const [unlocked, setUnlocked] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const expected = normalizeSecret(password);
    if (expected && normalizeSecret(value) === expected) {
      setUnlocked(true);
      setError("");
      playChime();
      onWin();
    } else {
      setError("Galat password. Hint padho, phir try karo… 🙈");
      void controls.start({ x: [0, -12, 12, -8, 8, -4, 4, 0], transition: { duration: 0.5 } });
    }
  };

  if (unlocked) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
        <p className="text-5xl">🔓</p>
        <p className="font-f1 mt-4 text-2xl font-black text-[#5ff0ff] [text-shadow:0_0_18px_#5ff0ff]">ACCESS GRANTED</p>
        <p className="font-display mx-auto mt-5 max-w-lg text-lg italic text-white/85">
          Secret unlocked: tum meri Malkin Ji ho, aur har password ka jawab bhi tum hi ho. 💖
        </p>
      </motion.div>
    );
  }

  return (
    <div className="grid gap-8 md:grid-cols-[1fr_1fr]">
      <div>
        <p className="label !text-[#5ff0ff]">Hints from Mr. Chopra</p>
        <ol className="mt-5 space-y-3">
          <AnimatePresence initial={false}>
            {hints.slice(0, revealed).map((h, i) => (
              <motion.li
                key={i}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass rounded-2xl p-4 text-sm leading-relaxed"
              >
                <span className="mr-2 font-f1 text-[#ff3dbb]">{String(i + 1).padStart(2, "0")}</span>
                {h}
              </motion.li>
            ))}
          </AnimatePresence>
        </ol>
        {revealed < hints.length ? (
          <button type="button" onClick={() => setRevealed((r) => r + 1)} className="btn btn-ghost mt-5 !min-h-10 !py-2 !text-[10px]">
            Need another hint
          </button>
        ) : (
          <p className="mt-5 text-xs text-white/50">All hints revealed. Think, Madam Ji. 🧩</p>
        )}
      </div>
      <motion.form
        onSubmit={submit}
        animate={controls}
        className="flex flex-col gap-4 self-start rounded-3xl border border-[#5ff0ff]/30 bg-black/40 p-6"
      >
        <label htmlFor="secret-password" className="label">
          Enter the secret password
        </label>
        <input
          id="secret-password"
          className="field font-f1 text-center text-lg tracking-[0.2em] uppercase"
          placeholder="• • • • • • • •"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          autoComplete="off"
        />
        <button type="submit" className="btn btn-accent" disabled={!value.trim()}>
          Unlock 🔐
        </button>
        <p className="min-h-[1.25rem] text-center text-xs text-[#ff8a80]" role="status">
          {error}
        </p>
      </motion.form>
    </div>
  );
}

/* ───────────── Hidden love messages ───────────── */
const TILES = 12;
const DECOYS = [
  "Nope, not here 🙈",
  "Keep searching, Madam Ji 🔍",
  "Warm… warmer… nahi, thoda aur 🔥",
  "Yahan kuch nahi, par tumhari smile yahan hai 😌",
];

function HiddenMessages({ messages, onWin }: { messages: string[]; onWin: () => void }) {
  const count = Math.min(messages.length, TILES);
  const [hits, setHits] = useState<number[]>([]);
  const [opened, setOpened] = useState<number[]>([]);
  const [found, setFound] = useState<number[]>([]);
  const [note, setNote] = useState<{ tile: number; text: string; hit: boolean } | null>(null);

  const shuffle = useCallback(() => {
    const idx = Array.from({ length: TILES }, (_, i) => i)
      .sort(() => Math.random() - 0.5)
      .slice(0, count);
    setHits(idx);
    setOpened([]);
    setFound([]);
    setNote(null);
  }, [count]);

  useEffect(() => {
    shuffle();
  }, [shuffle]);

  useEffect(() => {
    if (count > 0 && found.length === count) {
      onWin();
      playChime();
    }
  }, [found.length, count, onWin]);

  const reveal = (tile: number) => {
    if (opened.includes(tile)) return;
    setOpened((o) => [...o, tile]);
    const mi = hits.indexOf(tile);
    if (mi >= 0) {
      setFound((f) => [...f, tile]);
      setNote({ tile, text: messages[mi], hit: true });
      playChime();
    } else {
      setNote({ tile, text: pick(DECOYS), hit: false });
    }
  };

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 text-xs font-bold tracking-[0.2em] text-white/70">
        <span className="tabular">LOVE NOTES FOUND {found.length}/{count}</span>
        <button type="button" onClick={shuffle} className="btn btn-ghost !min-h-9 !px-4 !py-1.5 !text-[10px]">
          Shuffle hiding spots
        </button>
      </div>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
        {Array.from({ length: TILES }, (_, t) => {
          const isOpen = opened.includes(t);
          const isHit = isOpen && hits.includes(t);
          return (
            <motion.button
              key={t}
              type="button"
              onClick={() => reveal(t)}
              whileTap={{ scale: 0.92 }}
              aria-label={isOpen ? (isHit ? "Love note found" : "Empty tile") : "Hidden tile"}
              className={`aspect-square rounded-2xl border text-2xl transition-colors sm:text-3xl ${
                isHit
                  ? "border-[#ff3dbb] bg-[#ff3dbb]/25"
                  : isOpen
                    ? "border-white/10 bg-white/[0.03] text-white/25"
                    : "border-[#ff3dbb]/40 bg-gradient-to-br from-[#2a0b38] to-[#120418] hover:border-[#ff3dbb]"
              }`}
            >
              {isHit ? "💌" : isOpen ? "·" : "💗"}
            </motion.button>
          );
        })}
      </div>
      <div className="mt-6 min-h-[5rem] rounded-2xl border border-white/10 bg-black/40 p-5 text-center">
        <AnimatePresence mode="wait">
          {note ? (
            <motion.p
              key={`${note.tile}-${note.text}`}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`font-display text-lg italic sm:text-xl ${note.hit ? "text-[#ff8ad6]" : "text-white/60"}`}
            >
              {note.text}
            </motion.p>
          ) : (
            <motion.p key="empty" className="text-sm text-white/50">
              Tap a tile to reveal what&apos;s hiding inside.
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ───────────── Arcade shell ───────────── */
export default function ArcadePage() {
  const { settings, progress, markDone } = useSettings();
  const a = settings.arcade;
  const [active, setActive] = useState<GameId>("mrquiz");

  const cleared = (id: GameId) => progress.done.includes(`game:${id}`);
  const clearedCount = GAMES.filter((g) => cleared(g.id)).length;
  const allCleared = clearedCount === GAMES.length;

  const win = useCallback(() => markDone(`game:${active}`), [markDone, active]);

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#0b0410] pb-32 pt-28 text-white">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[50vh] opacity-40 arcade-grid [transform:perspective(500px)_rotateX(62deg)] origin-bottom" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,61,187,0.25),transparent_65%)] blur-2xl" />
      <FloatingParticles count={12} variant="sparks" colors={["#ff3dbb", "#5ff0ff"]} />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-10">
        <motion.header initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <p className="label !text-[#5ff0ff]">Website 06 · Insert coin</p>
          <h1 className="font-f1 mt-5 text-3xl font-black tracking-tight text-[#ff3dbb] [text-shadow:0_0_18px_#ff3dbb,0_0_44px_rgba(255,61,187,0.5)] sm:text-6xl">
            THE LOVE ARCADE
          </h1>
          <p className="mt-4 text-sm text-white/65 blink">PRESS START TO PLAY</p>
          <div className="mx-auto mt-6 flex max-w-md items-center gap-4">
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
              <motion.div
                className="h-full bg-gradient-to-r from-[#ff3dbb] to-[#5ff0ff]"
                animate={{ width: `${(clearedCount / GAMES.length) * 100}%` }}
                transition={{ duration: 0.6 }}
              />
            </div>
            <span className="tabular font-f1 text-xs font-bold">
              {clearedCount}/{GAMES.length}
            </span>
          </div>
        </motion.header>

        <nav className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-5" aria-label="Choose a game">
          {GAMES.map((g) => {
            const isActive = active === g.id;
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => setActive(g.id)}
                aria-pressed={isActive}
                className={`relative flex flex-col gap-2 rounded-2xl border p-4 text-left transition-all ${
                  isActive
                    ? "border-[#ff3dbb] bg-[#ff3dbb]/15 shadow-[0_0_30px_-6px_rgba(255,61,187,0.6)]"
                    : "border-white/10 bg-white/[0.03] hover:border-white/30"
                }`}
              >
                <span className="flex items-center justify-between">
                  <span className="text-2xl">{g.icon}</span>
                  <span className={`text-[9px] font-black tracking-[0.2em] ${cleared(g.id) ? "text-[#5ff0ff]" : "text-white/40"}`}>
                    {cleared(g.id) ? "CLEARED ✓" : "NEW"}
                  </span>
                </span>
                <span className="text-xs font-bold leading-snug sm:text-sm">{g.name}</span>
              </button>
            );
          })}
        </nav>

        <motion.section
          key={active}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="glass-strong mt-6 rounded-[32px] border-[#ff3dbb]/30 p-6 sm:p-10"
          aria-live="polite"
        >
          <p className="label !text-[#ff3dbb]">{GAMES.find((g) => g.id === active)?.blurb}</p>
          <h2 className="font-display mt-3 mb-8 text-3xl sm:text-4xl">{GAMES.find((g) => g.id === active)?.name}</h2>
          {active === "mrquiz" && (
            <Quiz
              key="mrquiz"
              questions={a.mrQuiz}
              results={["Perfect score! Aap officially Mr. Chopra ki sabse badi expert ho. 🏆", "Achha score hai! Thoda aur research karna padega. Mysterious rehne do mujhe. 😌", "Koi baat nahi. Mr. Chopra ko samajhna ek lifetime ka project hai. 💗"]}
              onComplete={win}
            />
          )}
          {active === "catch" && <CatchHearts onWin={win} />}
          {active === "password" && <PasswordGame password={a.password} hints={a.hints} onWin={win} />}
          {active === "romantic" && (
            <Quiz
              key="romantic"
              questions={a.romanticQuiz}
              results={["Perfect couple alert! Hum dono ek hi page pe hain. 💞", "Lagbhag perfect! Thodi aur date nights ki zaroorat hai. 🌹", "Ek aur round? Hum dono ko ab aur baatein karni padengi. 💬"]}
              onComplete={win}
            />
          )}
          {active === "hidden" && <HiddenMessages messages={a.hiddenMessages} onWin={win} />}
        </motion.section>

        <div className="mt-14 flex flex-col items-center gap-4 text-center">
          {allCleared ? (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center gap-4">
              <p className="font-f1 text-sm font-black tracking-[0.2em] text-[#5ff0ff]">ALL GAMES CLEARED · SECRET UNLOCKED</p>
              <FadeLink href="/finale" className="btn btn-gold !px-8 !py-4 !text-sm">
                Unlock the secret final surprise 🏁
              </FadeLink>
            </motion.div>
          ) : (
            <p className="text-xs text-white/45">Clear all five games to unlock the secret final surprise. ({clearedCount}/{GAMES.length})</p>
          )}
        </div>
      </div>
    </main>
  );
}
