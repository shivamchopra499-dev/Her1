"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import { THEMES, type Checkpoint, type Collection, type Gift, type Letter, type QuizQuestion, type Settings, type ThemeId } from "@/lib/defaults";
import { deletePhoto, deleteTrack, getTrack, listPhotos, saveTrack, updatePhoto, type PhotoRecord } from "@/lib/idb";
import { ensureSeeded, uploadFiles } from "@/lib/photos";
import { startAmbient, stopAmbient } from "@/lib/audio";
import { lines, paragraphs, uid } from "@/lib/utils";

/* ───────────── Small form primitives ───────────── */

function Panel({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="glass rounded-[28px] p-6 sm:p-8"
    >
      <h2 className="font-display text-2xl sm:text-3xl">{title}</h2>
      {desc && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/55">{desc}</p>}
      <div className="mt-7 space-y-6">{children}</div>
    </motion.section>
  );
}

function Input({
  label,
  value,
  onChange,
  placeholder,
  maxLength = 240,
  type = "text",
  className = "",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  maxLength?: number;
  type?: string;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      <input
        type={type}
        className="field mt-2"
        value={value}
        placeholder={placeholder}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

/** Multi-line field that saves on blur, so line breaks are never swallowed mid-typing. */
function Area({
  label,
  value,
  onCommit,
  rows = 4,
  hint,
}: {
  label: string;
  value: string;
  onCommit: (v: string) => void;
  rows?: number;
  hint?: string;
}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <label className="block">
      <span className="label">{label}</span>
      {hint && <span className="ml-2 text-[11px] normal-case tracking-normal text-white/40">{hint}</span>}
      <textarea
        className="field mt-2"
        rows={rows}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          if (draft !== value) onCommit(draft);
        }}
      />
    </label>
  );
}

function QuizEditor({
  title,
  questions,
  onChange,
}: {
  title: string;
  questions: QuizQuestion[];
  onChange: (q: QuizQuestion[]) => void;
}) {
  const update = (i: number, patch: Partial<QuizQuestion>) =>
    onChange(questions.map((q, idx) => (idx === i ? { ...q, ...patch } : q)));

  return (
    <div className="space-y-4">
      <p className="label !text-[color:var(--accent)]">{title}</p>
      {questions.map((q, i) => (
        <div key={i} className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="flex items-end gap-2">
            <Input label={`Question ${i + 1}`} value={q.q} onChange={(v) => update(i, { q: v })} className="flex-1" />
            <button type="button" onClick={() => onChange(questions.filter((_, x) => x !== i))} className="btn btn-ghost !min-h-10 !px-4 !py-2 !text-[10px]">
              Delete
            </button>
          </div>
          <p className="text-[11px] text-white/45">Tick the circle next to the correct answer.</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {q.options.map((o, oi) => (
              <label key={oi} className="flex items-center gap-3">
                <input
                  type="radio"
                  name={`answer-${title}-${i}`}
                  checked={q.answer === oi}
                  onChange={() => update(i, { answer: oi })}
                  className="h-4 w-4 accent-[color:var(--accent)]"
                  aria-label={`Option ${oi + 1} is correct`}
                />
                <input
                  className="field"
                  value={o}
                  maxLength={120}
                  onChange={(e) => update(i, { options: q.options.map((x, xi) => (xi === oi ? e.target.value : x)) })}
                  aria-label={`Option ${oi + 1}`}
                />
              </label>
            ))}
          </div>
        </div>
      ))}
      <button
        type="button"
        disabled={questions.length >= 10}
        onClick={() =>
          onChange([...questions, { q: "New question?", options: ["Option 1", "Option 2", "Option 3", "Option 4"], answer: 0 }])
        }
        className="btn btn-ghost"
      >
        + Add question
      </button>
    </div>
  );
}

/* ───────────── Sections ───────────── */

function ThemeSection() {
  const { settings, setSection } = useSettings();
  return (
    <Panel title="Theme" desc="Switches the accent colours across the whole universe: buttons, glows, nav, timeline dots and hearts. Each world keeps its own identity.">
      <div className="grid gap-4 md:grid-cols-3">
        {THEMES.map((t) => {
          const active = settings.theme === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSection("theme", t.id as ThemeId)}
              aria-pressed={active}
              className={`rounded-3xl border p-5 text-left transition-all ${active ? "border-white/60 bg-white/10 shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)]" : "border-white/10 hover:border-white/30"}`}
            >
              <div className="h-20 w-full rounded-2xl" style={{ background: `linear-gradient(135deg, ${t.swatch[0]}, ${t.swatch[1]})` }} />
              <p className="mt-4 font-semibold">{t.name}</p>
              <p className="mt-1 text-xs leading-relaxed text-white/55">{t.blurb}</p>
              {active && <p className="label mt-3 !text-[color:var(--accent)]">Active ✓</p>}
            </button>
          );
        })}
      </div>
    </Panel>
  );
}

function PhotosSection() {
  const { settings, setSection } = useSettings();
  const m = settings.memories;
  const [items, setItems] = useState<{ p: PhotoRecord; url: string }[]>([]);
  const [uploadTo, setUploadTo] = useState(m.collections[0]?.id ?? "");
  const [newName, setNewName] = useState("");
  const [busy, setBusy] = useState(false);
  const urlsRef = useRef<string[]>([]);

  const load = useCallback(async () => {
    urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    const records = await listPhotos();
    urlsRef.current = records.map((r) => URL.createObjectURL(r.blob));
    setItems(records.map((p, i) => ({ p, url: urlsRef.current[i] })));
  }, []);

  useEffect(() => {
    let alive = true;
    ensureSeeded().then(() => {
      if (alive) void load();
    });
    const urls = urlsRef;
    return () => {
      alive = false;
      urls.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [load]);

  const upload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      await uploadFiles(Array.from(files), uploadTo || m.collections[0]?.id || "c-favourites");
      await load();
    } finally {
      setBusy(false);
    }
  };

  const renameCollection = (id: string, name: string) =>
    setSection("memories", { ...m, collections: m.collections.map((c) => (c.id === id ? { ...c, name } : c)) });

  const addCollection = () => {
    const name = newName.trim();
    if (!name) return;
    const c: Collection = { id: uid("c"), name };
    setSection("memories", { ...m, collections: [...m.collections, c] });
    setUploadTo(c.id);
    setNewName("");
  };

  const removeCollection = async (id: string) => {
    const rest = m.collections.filter((c) => c.id !== id);
    if (rest.length === 0) return;
    const moveTo = rest[0].id;
    for (const { p } of items.filter((i) => i.p.collectionId === id)) {
      await updatePhoto(p.id, { collectionId: moveTo });
    }
    setSection("memories", { ...m, collections: rest });
    await load();
  };

  const saveCaption = async (id: string, caption: string) => {
    await updatePhoto(id, { caption });
    setItems((list) => list.map((i) => (i.p.id === id ? { ...i, p: { ...i.p, caption } } : i)));
  };

  const moveTo = async (id: string, collectionId: string) => {
    await updatePhoto(id, { collectionId });
    await load();
  };

  const remove = async (id: string) => {
    if (!window.confirm("Delete this photo from the browser?")) return;
    await deletePhoto(id);
    await load();
  };

  const removeSamples = async () => {
    if (!window.confirm("Delete all sample placeholder photos? Your uploads stay.")) return;
    for (const { p } of items.filter((i) => i.p.placeholder)) await deletePhoto(p.id);
    await load();
  };

  return (
    <Panel
      title="Photos, captions & collections"
      desc="Drop in Parthiba's photos, rename collections, and edit every caption. Photos are optimised and stored in this browser (IndexedDB). Sample placeholders can be removed any time."
    >
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-2xl border border-dashed border-white/25 p-5">
          <p className="label">Upload photos</p>
          <div className="mt-3 flex flex-wrap items-end gap-3">
            <label className="block min-w-[10rem] flex-1">
              <span className="sr-only">Collection</span>
              <select className="field" value={uploadTo} onChange={(e) => setUploadTo(e.target.value)}>
                {m.collections.map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#120a0e]">
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <label className={`btn btn-accent cursor-pointer ${busy ? "opacity-60" : ""}`}>
              {busy ? "Uploading…" : "Choose photos"}
              <input type="file" accept="image/*" multiple className="hidden" disabled={busy} onChange={(e) => { void upload(e.target.files); e.target.value = ""; }} />
            </label>
          </div>
          <p className="mt-3 text-xs text-white/45">Tip: you can also drag photos straight onto the gallery page.</p>
          <button type="button" onClick={removeSamples} className="btn btn-ghost mt-4 !min-h-9 !py-1.5 !text-[10px]">
            Remove sample placeholders
          </button>
        </div>

        <div className="rounded-2xl border border-white/10 p-5">
          <p className="label">Collections</p>
          <ul className="mt-3 space-y-2">
            {m.collections.map((c) => (
              <li key={c.id} className="flex items-center gap-2">
                <input className="field !py-2" value={c.name} maxLength={40} onChange={(e) => renameCollection(c.id, e.target.value)} aria-label="Collection name" />
                <button type="button" onClick={() => removeCollection(c.id)} disabled={m.collections.length < 2} className="btn btn-ghost !min-h-9 !px-3 !py-1 !text-[10px] disabled:opacity-30">
                  Delete
                </button>
              </li>
            ))}
          </ul>
          <form
            className="mt-4 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              addCollection();
            }}
          >
            <input className="field !py-2" placeholder="New collection…" value={newName} maxLength={40} onChange={(e) => setNewName(e.target.value)} />
            <button type="submit" className="btn btn-ghost !min-h-9 shrink-0 !px-4 !py-1" disabled={!newName.trim()}>
              Add
            </button>
          </form>
        </div>
      </div>

      <div>
        <p className="label mb-4">Photos ({items.length})</p>
        {items.length === 0 && <p className="text-sm text-white/50">No photos yet. Upload some above. 💗</p>}
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {items.map(({ p, url }) => (
            <li key={p.id} className="flex gap-4 rounded-2xl border border-white/10 bg-black/30 p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="h-24 w-20 shrink-0 rounded-xl object-cover" />
              <div className="flex min-w-0 flex-1 flex-col gap-2">
                <DraftCaption caption={p.caption} onSave={(v) => saveCaption(p.id, v)} />
                <select className="field !py-2 !text-xs" value={p.collectionId} onChange={(e) => moveTo(p.id, e.target.value)} aria-label="Move to collection">
                  {m.collections.map((c) => (
                    <option key={c.id} value={c.id} className="bg-[#120a0e]">
                      {c.name}
                    </option>
                  ))}
                </select>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-white/40">{p.placeholder ? "Sample" : "Uploaded"}</span>
                  <button type="button" onClick={() => remove(p.id)} className="text-[11px] font-semibold text-[#ff8a80] hover:underline">
                    Delete
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </Panel>
  );
}

function DraftCaption({ caption, onSave }: { caption: string; onSave: (v: string) => void }) {
  const [draft, setDraft] = useState(caption);
  useEffect(() => setDraft(caption), [caption]);
  return (
    <input
      className="field !py-2 font-display text-sm italic"
      value={draft}
      maxLength={160}
      placeholder="Caption…"
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft !== caption) onSave(draft);
      }}
      aria-label="Photo caption"
    />
  );
}

function MusicSection() {
  const { settings, setSection } = useSettings();
  const m = settings.memories;
  const [hasTrack, setHasTrack] = useState(false);
  const [trackName, setTrackName] = useState("");
  const [previewing, setPreviewing] = useState(false);

  useEffect(() => {
    getTrack().then((t) => {
      setHasTrack(!!t);
      setTrackName(t?.name ?? "");
    });
    return () => stopAmbient();
  }, []);

  const upload = async (file: File | undefined) => {
    if (!file) return;
    await saveTrack({ blob: file, name: file.name });
    setHasTrack(true);
    setTrackName(file.name);
    setSection("memories", { ...m, musicMode: "custom", musicTitle: file.name.replace(/\.[^.]+$/, "") });
  };

  return (
    <Panel
      title="Background music"
      desc="Choose the soundtrack for the gallery. 'Ambient' is a soft generated pad that needs no file. 'Custom' plays the song you upload here (stored in this browser)."
    >
      <div className="grid gap-3 sm:grid-cols-2">
        {(["ambient", "custom"] as const).map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => setSection("memories", { ...m, musicMode: mode })}
            aria-pressed={m.musicMode === mode}
            className={`rounded-2xl border p-5 text-left ${m.musicMode === mode ? "border-white/60 bg-white/10" : "border-white/10 hover:border-white/30"}`}
          >
            <p className="font-semibold">{mode === "ambient" ? "Ambient pad (built-in)" : "Our custom song"}</p>
            <p className="mt-1 text-xs text-white/55">
              {mode === "ambient" ? "Works immediately, no upload needed." : hasTrack ? `Uploaded: ${trackName}` : "Upload a track below first."}
            </p>
          </button>
        ))}
      </div>
      <Input label="Player title" value={m.musicTitle} onChange={(v) => setSection("memories", { ...m, musicTitle: v })} />
      <div className="flex flex-wrap items-center gap-3">
        <label className="btn btn-accent cursor-pointer">
          Upload audio file
          <input type="file" accept="audio/*" className="hidden" onChange={(e) => { void upload(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
        {hasTrack && (
          <button
            type="button"
            className="btn btn-ghost"
            onClick={async () => {
              await deleteTrack();
              setHasTrack(false);
              setTrackName("");
              setSection("memories", { ...m, musicMode: "ambient" });
            }}
          >
            Remove custom track
          </button>
        )}
        <button
          type="button"
          className="btn btn-ghost"
          onClick={() => {
            if (previewing) {
              stopAmbient();
              setPreviewing(false);
            } else {
              startAmbient();
              setPreviewing(true);
            }
          }}
        >
          {previewing ? "Stop ambient preview ❚❚" : "Preview ambient ▶"}
        </button>
      </div>
      <label className="block">
        <span className="label">Slideshow speed: {m.slideshowSeconds}s per photo</span>
        <input
          type="range"
          min={2}
          max={10}
          value={m.slideshowSeconds}
          onChange={(e) => setSection("memories", { ...m, slideshowSeconds: Number(e.target.value) })}
          className="mt-3 w-full accent-[color:var(--accent)]"
        />
      </label>
    </Panel>
  );
}

function TimelineSection() {
  const { settings, setSection } = useSettings();
  const list = settings.memories.timeline;
  const set = (next: typeof list) => setSection("memories", { ...settings.memories, timeline: next });
  return (
    <Panel title="Memory timeline" desc="Each entry appears on the gallery page, sorted by date. Add as many chapters as you like.">
      <div className="space-y-4">
        {list.map((entry, i) => (
          <div key={entry.id} className="grid gap-3 rounded-2xl border border-white/10 bg-black/30 p-4 sm:grid-cols-[10rem_1fr]">
            <Input label="Date" type="date" value={entry.date} onChange={(v) => set(list.map((x, xi) => (xi === i ? { ...x, date: v } : x)))} />
            <div className="space-y-3">
              <Input label="Title" value={entry.title} onChange={(v) => set(list.map((x, xi) => (xi === i ? { ...x, title: v } : x)))} />
              <Area label="Memory" rows={3} value={entry.text} onCommit={(v) => set(list.map((x, xi) => (xi === i ? { ...x, text: v } : x)))} />
              <button type="button" onClick={() => set(list.filter((_, xi) => xi !== i))} className="btn btn-ghost !min-h-9 !py-1 !text-[10px]">
                Delete memory
              </button>
            </div>
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={() => set([...list, { id: uid("m"), date: new Date().toISOString().slice(0, 10), title: "A new memory", text: "Likho kuch sweet si yaad..." }])}
        className="btn btn-accent"
      >
        + Add a memory
      </button>
    </Panel>
  );
}

function RaceSection() {
  const { settings, setSection } = useSettings();
  const r = settings.race;
  const set = (patch: Partial<Settings["race"]>) => setSection("race", { ...r, ...patch });
  const setCp = (i: number, patch: Partial<Checkpoint>) =>
    set({ checkpoints: r.checkpoints.map((c, idx) => (idx === i ? { ...c, ...patch } : c)) });
  return (
    <Panel title="The Race of Love" desc="Opening text, pole-position line, the six checkpoint memories and the finish line message.">
      <Input label="Welcome title" value={r.welcomeTitle} onChange={(v) => set({ welcomeTitle: v })} />
      <Input label="Subtitle" value={r.subtitle} onChange={(v) => set({ subtitle: v })} />
      <Input label="Pole position line" value={r.polePosition} onChange={(v) => set({ polePosition: v })} />
      <Input label="Finish line message" value={r.finishLine} onChange={(v) => set({ finishLine: v })} />
      <div className="space-y-4">
        <p className="label !text-[color:var(--accent)]">Checkpoints (the circuit has six)</p>
        {r.checkpoints.map((c, i) => (
          <div key={i} className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
            <Input label={`Checkpoint ${i + 1} title`} value={c.title} onChange={(v) => setCp(i, { title: v })} />
            <Area label="Message" rows={3} value={c.message} onCommit={(v) => setCp(i, { message: v })} />
          </div>
        ))}
      </div>
    </Panel>
  );
}

function MrsSection() {
  const { settings, setSection } = useSettings();
  const m = settings.mrs;
  const set = (patch: Partial<Settings["mrs"]>) => setSection("mrs", { ...m, ...patch });
  return (
    <Panel title="The Mrs. Chopra Experience" desc="Hero line, royal title, the love certificate, Mr. Chopra's special message and the crown letter.">
      <Input label="Hero line" value={m.heroLine} onChange={(v) => set({ heroLine: v })} />
      <Input label="Royal title" value={m.title} onChange={(v) => set({ title: v })} />
      <Input label="Certificate title" value={m.certificateTitle} onChange={(v) => set({ certificateTitle: v })} />
      <Area label="Certificate body" rows={4} value={m.certificateBody} onCommit={(v) => set({ certificateBody: v })} />
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Certificate date line" value={m.certificateDate} onChange={(v) => set({ certificateDate: v })} />
        <Input label="Issued by" value={m.certificateIssuer} onChange={(v) => set({ certificateIssuer: v })} />
      </div>
      <Input label="Special message title" value={m.specialTitle} onChange={(v) => set({ specialTitle: v })} />
      <Area label="Special message" hint="Blank line = new paragraph" rows={6} value={m.specialMessage} onCommit={(v) => set({ specialMessage: v })} />
      <Input label="Crown button title" value={m.crownTitle} onChange={(v) => set({ crownTitle: v })} />
      <Area label="Crown love letter" hint="Blank line = new paragraph" rows={10} value={m.crownLetter} onCommit={(v) => set({ crownLetter: v })} />
      <Input label="Reply box prompt" value={m.replyPrompt} onChange={(v) => set({ replyPrompt: v })} />
    </Panel>
  );
}

function DoraemonSection() {
  const { settings, setSection } = useSettings();
  const d = settings.doraemon;
  const set = (patch: Partial<Settings["doraemon"]>) => setSection("doraemon", { ...d, ...patch });
  const setGift = (i: number, patch: Partial<Gift>) => set({ gifts: d.gifts.map((g, idx) => (idx === i ? { ...g, ...patch } : g)) });
  return (
    <Panel title="Doraemon's Secret World" desc="One item per line for the lists. These feed the nickname roulette, funny messages, surprise button and the anywhere door.">
      <Input label="Opening alert" value={d.alert} onChange={(v) => set({ alert: v })} />
      <Area label="Nicknames" hint="one per line" rows={6} value={d.nicknames.join("\n")} onCommit={(v) => set({ nicknames: lines(v) })} />
      <Area label="Funny messages" hint="one per line" rows={6} value={d.funnyMessages.join("\n")} onCommit={(v) => set({ funnyMessages: lines(v) })} />
      <Area label="Affectionate messages" hint="one per line" rows={6} value={d.affectionateMessages.join("\n")} onCommit={(v) => set({ affectionateMessages: lines(v) })} />
      <div className="space-y-4">
        <p className="label !text-[color:var(--accent)]">Digital gifts</p>
        {d.gifts.map((g, i) => (
          <div key={g.id} className="grid gap-3 rounded-2xl border border-white/10 bg-black/30 p-4 sm:grid-cols-[5rem_1fr]">
            <Input label="Emoji" value={g.emoji} maxLength={4} onChange={(v) => setGift(i, { emoji: v })} />
            <div className="space-y-3">
              <Input label="Name" value={g.name} onChange={(v) => setGift(i, { name: v })} />
              <Area label="Message" rows={2} value={g.message} onCommit={(v) => setGift(i, { message: v })} />
              <button type="button" onClick={() => set({ gifts: d.gifts.filter((_, x) => x !== i) })} className="btn btn-ghost !min-h-9 !py-1 !text-[10px]">
                Delete gift
              </button>
            </div>
          </div>
        ))}
        <button
          type="button"
          onClick={() => set({ gifts: [...d.gifts, { id: uid("g"), emoji: "🎁", name: "New gadget", message: "Ek naya surprise, sirf tumhare liye." }] })}
          className="btn btn-accent"
        >
          + Add a gift
        </button>
      </div>
    </Panel>
  );
}

function LettersSection() {
  const { settings, setSection } = useSettings();
  const letters = settings.letters;
  const set = (next: Letter[]) => setSection("letters", next);
  const update = (i: number, patch: Partial<Letter>) => set(letters.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  return (
    <Panel title="Open When… letters" desc="Edit every envelope. Add new moods, change emojis, rewrite the body in your own Hinglish. Blank line = new paragraph.">
      <div className="space-y-5">
        {letters.map((l, i) => (
          <div key={l.id} className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
            <div className="grid gap-3 sm:grid-cols-[5rem_1fr]">
              <Input label="Emoji" value={l.emoji} maxLength={4} onChange={(v) => update(i, { emoji: v })} />
              <Input label="Envelope label" value={l.title} onChange={(v) => update(i, { title: v })} />
            </div>
            <Area label="Letter body" rows={8} value={l.body} onCommit={(v) => update(i, { body: v })} />
            <Input label="Signature" value={l.signature} onChange={(v) => update(i, { signature: v })} />
            <button type="button" onClick={() => set(letters.filter((_, x) => x !== i))} className="btn btn-ghost !min-h-9 !py-1 !text-[10px]">
              Delete letter
            </button>
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={() =>
          set([
            ...letters,
            { id: uid("letter"), emoji: "💫", title: "Open when you need a reminder", body: "Malkin Ji,\n\nTum special ho. Hamesha.", signature: "Mr. Chopra" },
          ])
        }
        className="btn btn-accent"
      >
        + Add a letter
      </button>
    </Panel>
  );
}

function ArcadeSection() {
  const { settings, setSection } = useSettings();
  const a = settings.arcade;
  const set = (patch: Partial<Settings["arcade"]>) => setSection("arcade", { ...a, ...patch });
  return (
    <Panel title="The Love Arcade" desc="Secret password, its hints, the two quizzes and the hidden love notes.">
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Secret password (letters/numbers)" value={a.password} maxLength={40} onChange={(v) => set({ password: v })} />
      </div>
      <Area label="Password hints" hint="one per line" rows={4} value={a.hints.join("\n")} onCommit={(v) => set({ hints: lines(v) })} />
      <Area label="Hidden love messages" hint="one per line (max 12)" rows={5} value={a.hiddenMessages.join("\n")} onCommit={(v) => set({ hiddenMessages: lines(v).slice(0, 12) })} />
      <QuizEditor title="How well do you know Mr. Chopra?" questions={a.mrQuiz} onChange={(q) => set({ mrQuiz: q })} />
      <QuizEditor title="Romantic quiz" questions={a.romanticQuiz} onChange={(q) => set({ romanticQuiz: q })} />
    </Panel>
  );
}

function FinaleSection() {
  const { settings, setSection } = useSettings();
  const f = settings.finale;
  return (
    <Panel title="The final surprise" desc="The cinematic text after the hidden button. Separate every line or block with a blank line.">
      <Area label="Finale lines" hint="blank line between each" rows={10} value={f.lines.join("\n\n")} onCommit={(v) => setSection("finale", { ...f, lines: paragraphs(v) })} />
      <Input label="Final sign-off line" value={f.signoff} onChange={(v) => setSection("finale", { ...f, signoff: v })} />
      <Link href="/finale" className="btn btn-gold w-fit">
        Preview the finale 🏁
      </Link>
    </Panel>
  );
}

type Note = { id: number; message: string; createdAt: string };

function InboxSection() {
  const [notes, setNotes] = useState<Note[] | null>(null);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    setError("");
    try {
      const res = await fetch("/api/notes", { cache: "no-store" });
      const data = (await res.json()) as { notes?: Note[]; error?: string };
      if (!res.ok || !data.notes) throw new Error(data.error ?? "failed");
      setNotes(data.notes);
    } catch {
      setError("The inbox is unavailable right now (database offline?).");
      setNotes([]);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Panel title="Replies from Madam Ji" desc="Notes Mrs. Chopra sends from the Mrs. Chopra page are stored on the server (PostgreSQL) and appear here.">
      <button type="button" onClick={load} className="btn btn-ghost w-fit !min-h-9 !py-1.5 !text-[10px]">
        Refresh inbox
      </button>
      {error && <p className="text-sm text-[#ff8a80]">{error}</p>}
      {notes === null && <p className="text-sm text-white/50">Loading…</p>}
      {notes && notes.length === 0 && !error && <p className="text-sm text-white/50">No replies yet. Madam Ji will write soon. 💌</p>}
      <ul className="space-y-3">
        {notes?.map((n) => (
          <li key={n.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
            <p className="label !text-[9px]">{new Date(n.createdAt).toLocaleString("en-IN")}</p>
            <p className="mt-2 whitespace-pre-line font-display text-lg italic">{n.message}</p>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function BackupSection() {
  const { settings, replaceSettings, resetSettings, resetProgress } = useSettings();
  const fileRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(settings, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mrs-chopra-universe-settings.json";
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    setMessage("Settings exported. Photos are not included in this file.");
  };

  const importJson = async (file: File | undefined) => {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text()) as Partial<Settings>;
      replaceSettings(data);
      setMessage("Settings imported ✓");
    } catch {
      setMessage("That file isn't a valid settings export.");
    }
  };

  return (
    <Panel title="Backup & reset" desc="Your words, theme and progress live in this browser. Export a backup file so you never lose them.">
      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={exportJson} className="btn btn-accent">
          Export settings (.json)
        </button>
        <button type="button" onClick={() => fileRef.current?.click()} className="btn btn-ghost">
          Import settings
        </button>
        <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={(e) => { void importJson(e.target.files?.[0]); e.target.value = ""; }} />
      </div>
      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          className="btn btn-ghost"
          onClick={() => {
            if (window.confirm("Reset every sentence, theme and nickname back to the original defaults?")) {
              resetSettings();
              setMessage("Settings reset to defaults.");
            }
          }}
        >
          Reset words to defaults
        </button>
        <button
          type="button"
          className="btn btn-ghost"
          onClick={() => {
            if (window.confirm("Clear all 'explored' and 'cleared' progress? The hidden button will lock again.")) {
              resetProgress();
              setMessage("Progress cleared.");
            }
          }}
        >
          Reset progress
        </button>
      </div>
      {message && (
        <p role="status" className="text-sm text-white/70">
          {message}
        </p>
      )}
    </Panel>
  );
}

/* ───────────── Studio shell ───────────── */

const SECTIONS = [
  { id: "theme", label: "Theme", icon: "🎨" },
  { id: "photos", label: "Photos & captions", icon: "📸" },
  { id: "music", label: "Music", icon: "🎵" },
  { id: "timeline", label: "Memory timeline", icon: "🗓️" },
  { id: "race", label: "Race of Love", icon: "🏎️" },
  { id: "mrs", label: "Mrs. Chopra", icon: "👑" },
  { id: "doraemon", label: "Doraemon", icon: "💙" },
  { id: "letters", label: "Letters", icon: "💌" },
  { id: "arcade", label: "Arcade", icon: "🎮" },
  { id: "finale", label: "Finale", icon: "🏁" },
  { id: "inbox", label: "Replies inbox", icon: "📨" },
  { id: "backup", label: "Backup & reset", icon: "🧰" },
] as const;

type SectionId = (typeof SECTIONS)[number]["id"];

export default function StudioPage() {
  const [active, setActive] = useState<SectionId>("theme");
  const { ready } = useSettings();

  const content: Record<SectionId, React.ReactNode> = {
    theme: <ThemeSection />,
    photos: <PhotosSection />,
    music: <MusicSection />,
    timeline: <TimelineSection />,
    race: <RaceSection />,
    mrs: <MrsSection />,
    doraemon: <DoraemonSection />,
    letters: <LettersSection />,
    arcade: <ArcadeSection />,
    finale: <FinaleSection />,
    inbox: <InboxSection />,
    backup: <BackupSection />,
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#070709] pb-32 pt-24 text-white">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(225,6,0,0.14),transparent_50%),radial-gradient(ellipse_at_bottom_right,rgba(231,166,184,0.1),transparent_50%)]" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-10">
        <header className="mb-10">
          <p className="label !text-[color:var(--accent)]">Personalisation Studio</p>
          <h1 className="font-display mt-4 text-4xl sm:text-6xl">
            Shape the <span className="italic text-white/70">universe.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/60">
            Every word, photo, nickname, letter and password on the site can be edited here. Changes save automatically in this browser. No code needed.
            {!ready && " Loading your saved universe…"}
          </p>
        </header>

        <div className="grid gap-8 lg:grid-cols-[17rem_1fr]">
          <nav aria-label="Studio sections" className="no-scrollbar sticky top-20 z-10 -mx-5 flex gap-2 overflow-x-auto px-5 lg:mx-0 lg:h-fit lg:flex-col lg:overflow-visible lg:px-0">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setActive(s.id)}
                aria-current={active === s.id ? "true" : undefined}
                className={`relative flex shrink-0 items-center gap-3 rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition-colors ${
                  active === s.id ? "border-transparent bg-white/10 text-white" : "border-white/10 text-white/55 hover:border-white/25 hover:text-white"
                }`}
              >
                {active === s.id && <motion.span layoutId="studio-active" className="absolute inset-y-2 left-0 w-1 rounded-full bg-[color:var(--accent)]" />}
                <span aria-hidden>{s.icon}</span>
                <span className="whitespace-nowrap">{s.label}</span>
              </button>
            ))}
          </nav>

          <div className="min-w-0">
            <AnimatePresence mode="wait">
              <motion.div key={active} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.25 }}>
                {content[active]}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </main>
  );
}
