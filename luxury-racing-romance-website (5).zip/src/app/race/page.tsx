import type { Metadata } from "next";
import { RaceExperience } from "@/components/race/race-experience";

export const metadata: Metadata = {
  title: "The Race of Love — Mrs. Chopra",
};

export default function RacePage() {
  return <RaceExperience />;
}
