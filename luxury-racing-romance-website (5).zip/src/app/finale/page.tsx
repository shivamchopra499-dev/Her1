"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from "@/lib/store";
import { FloatingParticles } from "@/components/floating-particles";

export default function FinalePage() {
  const { settings } = useSettings();
  const lines = settings.finale.lines;
  const items = [...lines, settings.finale.signoff];
  const [step, setStep] = useState(0);
  const [dark, setDark] = useState(true);

  // Fade in from black once, then reveal line by line.
  useEffect(() => {
    const t = window.setTimeout(() => setDark(false), 400);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    if (step >= items.length) return;
    const t = window.setTimeout(() => setStep((s) => s + 1), step === 0 ? 1800 : 2800);
    return () => window.clearTimeout(t);
  }, [step, items.length]);

  const finished = step >= items.length;
  const signoffIndex = items.length - 1;

  return (
    <main className="relative min-h-[100svh] overflow-hidden bg-black text-white">
      <FloatingParticles count={34} variant="stars" colors={["#ffffff", "#f6e7b0", "#ff7aa2"]} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(225,6,0,0.12),transparent_60%)]" />

      {/* Cinematic letterbox */}
      <motion.div initial={{ height: "12vh" }} animate={{ height: "9vh" }} transition={{ duration: 2 }} className="pointer-events-none absolute inset-x-0 top-0 z-10 bg-black" />
      <motion.div initial={{ height: "12vh" }} animate={{ height: "9vh" }} transition={{ duration: 2 }} className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-black" />

      <div className="relative z-20 flex min-h-[100svh] flex-col items-center justify-center px-6 py-24 text-center">
        <div className="flex max-w-4xl flex-col items-center gap-7">
          {items.slice(0, Math.min(step, items.length)).map((line, i) => {
            const isSignoff = i === signoffIndex;
            const isName = line.trim() === "PARTHIBA.";
            if (isSignoff) return null;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 24, filter: "blur(12px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
                className="whitespace-pre-line"
              >
                {isName ? (
                  <p className="font-f1 gold-text text-5xl font-black tracking-[0.15em] sm:text-8xl">{line}</p>
                ) : (
                  <p className="font-display text-2xl italic leading-relaxed text-white/90 sm:text-4xl">{line}</p>
                )}
              </motion.div>
            );
          })}

          <AnimatePresence>
            {finished && (
              <motion.div
                key="signoff"
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.4, ease: "easeOut" }}
                className="mt-6 flex flex-col items-center gap-8"
              >
                <p className="font-f1 text-xl font-black leading-snug tracking-wide text-[color:var(--accent)] glow-red sm:text-3xl">
                  {settings.finale.signoff}
                </p>
                <div className="flex flex-wrap justify-center gap-3">
                  <Link href="/" className="btn btn-ghost">
                    Back to the universe
                  </Link>
                  <button type="button" onClick={() => setStep(0)} className="btn btn-ghost">
                    Replay ↺
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {!finished && (
        <button
          type="button"
          onClick={() => setStep(items.length)}
          className="absolute bottom-16 left-1/2 z-30 -translate-x-1/2 text-[10px] tracking-[0.3em] text-white/40 hover:text-white"
        >
          SKIP ▸
        </button>
      )}

      <motion.div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[60] bg-black"
        initial={{ opacity: 1 }}
        animate={{ opacity: dark ? 1 : 0 }}
        transition={{ duration: 2.2, ease: "easeInOut" }}
      />
    </main>
  );
}
