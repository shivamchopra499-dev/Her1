import type { Metadata } from "next";
import { GalleryExperience } from "@/components/memories/gallery-experience";

export const metadata: Metadata = {
  title: "Our Private Gallery — Mrs. Chopra",
};

export default function MemoriesPage() {
  return <GalleryExperience />;
}
